package com.clipperdirac.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ClipRecord(val title: String, val reason: String, val uri: String, val name: String, val dur: Double)
data class Project(val folder: String, val clips: List<ClipRecord>)

fun slug(s: String, def: String = "video"): String =
    s.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').take(40).ifEmpty { def }

object Gallery {
    /** Clip ko Movies/Clipperdirac/<video_folder>/ me save karta hai (Gallery me dikhegi). */
    fun save(ctx: Context, file: File, folder: String, displayName: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Clipperdirac/" + folder)
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Gallery me save nahi ho paya")
        resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
        resolver.update(uri, done, null, null)
        return uri
    }
}

object ProjectStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "projects.json")

    fun load(ctx: Context): List<Project> {
        val f = file(ctx)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val cs = o.getJSONArray("clips")
                Project(
                    o.getString("folder"),
                    (0 until cs.length()).map { j ->
                        val c = cs.getJSONObject(j)
                        ClipRecord(
                            c.getString("title"), c.optString("reason"), c.getString("uri"),
                            c.getString("name"), c.optDouble("dur", 0.0)
                        )
                    }
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun add(ctx: Context, p: Project): List<Project> {
        val all = listOf(p) + load(ctx)
        val arr = JSONArray()
        for (pr in all) {
            val cs = JSONArray()
            for (c in pr.clips) {
                cs.put(
                    JSONObject().put("title", c.title).put("reason", c.reason)
                        .put("uri", c.uri).put("name", c.name).put("dur", c.dur)
                )
            }
            arr.put(JSONObject().put("folder", pr.folder).put("clips", cs))
        }
        file(ctx).writeText(arr.toString())
        return all
    }
}
