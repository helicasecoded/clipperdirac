package com.clipperdirac.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ClipRecord(
    val title: String,
    val reason: String,
    val uri: String,
    val name: String,
    val dur: Double,
    val ytTitle: String = "",
    val ytDesc: String = "",
    val igCaption: String = "",
    val hashtags: String = "",
    val start: Double = 0.0,
    val end: Double = 0.0,
    val remove: String = "",
    val hookS: Double = -1.0,
    val hookE: Double = -1.0,
    val headline: String = "",
    val capsText: String = "",
    val score: Double = 0.0,
    val views: Long = 0L,
)

data class Project(val folder: String, val source: String, val clips: List<ClipRecord>)

data class Campaign(
    val id: Long,
    val platform: String,
    val name: String,
    val creator: String,
    val link: String,
    val status: String,
    val views: Long,
    val cpm: Double,
)

fun slug(s: String, def: String = "video"): String =
    s.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').take(40).ifEmpty { def }

object RemoveCodec {
    fun encode(r: List<DoubleArray>): String = r.joinToString(";") { "${it[0]},${it[1]}" }

    fun decode(s: String): List<DoubleArray> {
        if (s.isBlank()) return emptyList()
        return s.split(";").mapNotNull { p ->
            val a = p.split(",")
            val x = a.getOrNull(0)?.toDoubleOrNull()
            val y = a.getOrNull(1)?.toDoubleOrNull()
            if (a.size == 2 && x != null && y != null) doubleArrayOf(x, y) else null
        }
    }
}

object Gallery {
    /** Clip ko Movies/Clipperdirac/<video_folder>/ me save karta hai (Gallery me dikhegi). */
    fun save(ctx: Context, file: File, folder: String, displayName: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Clipperdirac/" + folder)
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Gallery me save nahi ho paya")
        resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
        resolver.update(uri, done, null, null)
        return uri
    }

    fun delete(ctx: Context, uri: String) {
        try { ctx.contentResolver.delete(Uri.parse(uri), null, null) } catch (_: Exception) {}
    }
}

object ProjectStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "projects.json")

    private fun clipToJson(c: ClipRecord) = JSONObject()
        .put("title", c.title).put("reason", c.reason).put("uri", c.uri).put("name", c.name)
        .put("dur", c.dur).put("yt_title", c.ytTitle).put("yt_desc", c.ytDesc)
        .put("ig_caption", c.igCaption).put("hashtags", c.hashtags)
        .put("start", c.start).put("end", c.end).put("remove", c.remove)
        .put("hook_s", c.hookS).put("hook_e", c.hookE).put("headline", c.headline)
        .put("caps_text", c.capsText).put("score", c.score).put("views", c.views)

    private fun clipFromJson(c: JSONObject) = ClipRecord(
        title = c.optString("title"), reason = c.optString("reason"), uri = c.getString("uri"),
        name = c.optString("name"), dur = c.optDouble("dur", 0.0),
        ytTitle = c.optString("yt_title"), ytDesc = c.optString("yt_desc"),
        igCaption = c.optString("ig_caption"), hashtags = c.optString("hashtags"),
        start = c.optDouble("start", 0.0), end = c.optDouble("end", 0.0), remove = c.optString("remove"),
        hookS = c.optDouble("hook_s", -1.0), hookE = c.optDouble("hook_e", -1.0),
        headline = c.optString("headline"), capsText = c.optString("caps_text"),
        score = c.optDouble("score", 0.0), views = c.optLong("views", 0L),
    )

    fun load(ctx: Context): List<Project> {
        val f = file(ctx)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val cs = o.getJSONArray("clips")
                Project(
                    o.getString("folder"), o.optString("source"),
                    (0 until cs.length()).map { j -> clipFromJson(cs.getJSONObject(j)) }
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun save(ctx: Context, all: List<Project>) {
        val arr = JSONArray()
        for (p in all) {
            val cs = JSONArray()
            for (c in p.clips) cs.put(clipToJson(c))
            arr.put(JSONObject().put("folder", p.folder).put("source", p.source).put("clips", cs))
        }
        file(ctx).writeText(arr.toString())
    }

    fun add(ctx: Context, p: Project): List<Project> {
        val all = listOf(p) + load(ctx)
        save(ctx, all)
        return all
    }

    fun updateClip(ctx: Context, folder: String, index: Int, rec: ClipRecord): List<Project> {
        val all = load(ctx).map { p ->
            if (p.folder != folder) p
            else p.copy(clips = p.clips.mapIndexed { i, c -> if (i == index) rec else c })
        }
        save(ctx, all)
        return all
    }

    fun removeClip(ctx: Context, folder: String, index: Int): List<Project> {
        val all = load(ctx).map { p ->
            if (p.folder != folder) p else p.copy(clips = p.clips.filterIndexed { i, _ -> i != index })
        }.filter { it.clips.isNotEmpty() }
        save(ctx, all)
        return all
    }

    fun saveWords(ctx: Context, folder: String, words: List<Word>) {
        val arr = JSONArray()
        for (w in words) arr.put(JSONArray().put(w.w).put(w.s).put(w.e))
        File(ctx.filesDir, "words_$folder.json").writeText(arr.toString())
    }

    fun loadWords(ctx: Context, folder: String): List<Word> {
        val f = File(ctx.filesDir, "words_$folder.json")
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map {
                val a = arr.getJSONArray(it)
                Word(a.getString(0), a.getDouble(1), a.getDouble(2))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}

object CampaignStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "campaigns.json")

    fun load(ctx: Context): List<Campaign> {
        val f = file(ctx)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Campaign(
                    o.getLong("id"), o.optString("platform"), o.optString("name"), o.optString("creator"),
                    o.optString("link"), o.optString("status", "Submitted"),
                    o.optLong("views", 0L), o.optDouble("cpm", 0.0)
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Campaign>) {
        val arr = JSONArray()
        for (c in list) {
            arr.put(
                JSONObject().put("id", c.id).put("platform", c.platform).put("name", c.name)
                    .put("creator", c.creator).put("link", c.link).put("status", c.status)
                    .put("views", c.views).put("cpm", c.cpm)
            )
        }
        file(ctx).writeText(arr.toString())
    }
}
