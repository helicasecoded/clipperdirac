package com.clipperdirac.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class LlmException(msg: String, val code: Int = 0) : Exception(msg)

class Provider(val kind: String, val key: String, val label: String, val modelOverride: String)

/**
 * Gemini key 1, Gemini key 2 aur Grok key ko round-robin me use karta hai.
 * Koi key limit (429) ya error de to agli key try hoti hai.
 */
object KeyParser {
    /** Kisi bhi number ki keys: whitespace/comma/semicolon se alag. "xai-" = Grok, baaki Gemini. */
    fun parse(text: String): List<Pair<String, String>> =
        text.split(Regex("[\\s,;]+")).map { it.trim() }.filter { it.length > 15 }.distinct()
            .map { (if (it.startsWith("xai-")) "grok" else "gemini") to it }

    fun summary(text: String): String {
        val k = parse(text)
        val g = k.count { it.first == "gemini" }
        val x = k.count { it.first == "grok" }
        return "Gemini keys: $g  |  Grok keys: $x"
    }
}

class LlmRouter(s: Settings, private val log: (String) -> Unit) {
    private val providers = ArrayList<Provider>().apply {
        var g = 0
        var x = 0
        for ((kind, key) in KeyParser.parse(s.keys)) {
            if (kind == "gemini") { g++; add(Provider("gemini", key, "Gemini-$g", s.geminiModel.trim())) }
            else { x++; add(Provider("grok", key, "Grok-$x", s.grokModel.trim())) }
        }
    }
    private val cooldownUntil = HashMap<String, Long>()
    private val grokModelCache = HashMap<String, String>()
    private var next = 0

    val isEmpty: Boolean get() = providers.isEmpty()

    /** Blocking call: background thread se hi chalao. */
    fun generateJson(prompt: String): String {
        if (providers.isEmpty()) throw LlmException("Koi API key nahi hai")
        val n = providers.size
        val errors = ArrayList<String>()
        for (attempt in 0 until 3) {
            for (i in 0 until n) {
                val p = providers[(next + i) % n]
                val until = cooldownUntil[p.label] ?: 0L
                if (attempt == 0 && System.currentTimeMillis() < until) continue
                try {
                    val out = if (p.kind == "gemini") callGemini(p, prompt) else callGrok(p, prompt)
                    next = (next + i + 1) % n
                    return out
                } catch (e: LlmException) {
                    log("${p.label}: ${e.message?.take(120)}")
                    errors.add("${p.label}: ${e.message?.take(80)}")
                    val now = System.currentTimeMillis()
                    cooldownUntil[p.label] = when (e.code) {
                        429, 500, 502, 503, 504 -> now + 60_000
                        401, 403 -> now + 3_600_000
                        else -> now + 20_000
                    }
                }
            }
            if (attempt < 2) {
                log("Saari keys busy, 15 sec ruk ke retry...")
                Thread.sleep(15_000)
            }
        }
        throw LlmException("Saari keys fail: " + errors.takeLast(3).joinToString(" | "))
    }

    /** Google Search grounding (sirf Gemini keys). Fail ho to khali string, crash nahi. */
    fun searchText(prompt: String): String {
        for (p in providers.filter { it.kind == "gemini" }) {
            val models = if (p.modelOverride.isNotBlank()) listOf(p.modelOverride)
            else listOf("gemini-flash-latest", "gemini-flash-lite-latest")
            for (m in models) {
                try {
                    val body = JSONObject()
                        .put(
                            "contents",
                            JSONArray().put(
                                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                            )
                        )
                        .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
                        .put("generationConfig", JSONObject().put("temperature", 0.3))
                    val resp = http(
                        "POST",
                        "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                        mapOf("x-goog-api-key" to p.key),
                        body.toString()
                    )
                    val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts")
                    val sb = StringBuilder()
                    for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                    if (sb.isNotBlank()) return sb.toString()
                } catch (e: LlmException) {
                    log("${p.label} search: ${e.message?.take(80)}")
                    if (e.code != 404) break
                } catch (e: org.json.JSONException) {
                    break
                }
            }
        }
        return ""
    }

    private fun callGemini(p: Provider, prompt: String): String {
        val models = if (p.modelOverride.isNotBlank()) listOf(p.modelOverride)
        else listOf("gemini-flash-latest", "gemini-flash-lite-latest")
        var last: LlmException? = null
        for (m in models) {
            try {
                val body = JSONObject()
                    .put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                        )
                    )
                    .put(
                        "generationConfig",
                        JSONObject().put("temperature", 0.3).put("responseMimeType", "application/json")
                    )
                val resp = http(
                    "POST",
                    "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                    mapOf("x-goog-api-key" to p.key),
                    body.toString()
                )
                val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                val sb = StringBuilder()
                for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                if (sb.isBlank()) throw LlmException("Gemini ne khali jawab diya", 0)
                return sb.toString()
            } catch (e: LlmException) {
                last = e
                if (e.code != 404) throw e
            } catch (e: org.json.JSONException) {
                throw LlmException("Gemini ka response samajh nahi aaya", 0)
            }
        }
        throw last ?: LlmException("Gemini fail")
    }

    private fun resolveGrokModel(p: Provider): String {
        if (p.modelOverride.isNotBlank()) return p.modelOverride
        grokModelCache[p.label]?.let { return it }
        var chosen = "grok-4"
        try {
            val resp = http("GET", "https://api.x.ai/v1/models", mapOf("Authorization" to "Bearer ${p.key}"), null)
            val arr = JSONObject(resp).optJSONArray("data") ?: JSONArray()
            var bestFast: String? = null
            var bestFastT = -1L
            var best: String? = null
            var bestT = -1L
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                val id = m.optString("id")
                val low = id.lowercase()
                if (!low.startsWith("grok")) continue
                if (listOf("image", "imagine", "video", "vision", "embed", "tts", "stt", "code").any { low.contains(it) }) continue
                val created = m.optLong("created", 0L)
                if (low.contains("fast") && created >= bestFastT) { bestFast = id; bestFastT = created }
                if (created >= bestT) { best = id; bestT = created }
            }
            chosen = bestFast ?: best ?: chosen
        } catch (_: Exception) {
        }
        grokModelCache[p.label] = chosen
        return chosen
    }

    private fun callGrok(p: Provider, prompt: String): String {
        val model = resolveGrokModel(p)
        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0.3)
            .put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", "You output only valid JSON, nothing else."))
                    .put(JSONObject().put("role", "user").put("content", prompt))
            )
        val resp = http(
            "POST", "https://api.x.ai/v1/chat/completions",
            mapOf("Authorization" to "Bearer ${p.key}"), body.toString()
        )
        try {
            return JSONObject(resp).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        } catch (e: org.json.JSONException) {
            throw LlmException("Grok ka response samajh nahi aaya", 0)
        }
    }

    private fun http(method: String, url: String, headers: Map<String, String>, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20_000
            c.readTimeout = 180_000
            c.setRequestProperty("Content-Type", "application/json")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw LlmException("HTTP $code ${text.take(160)}", code)
            return text
        } catch (e: IOException) {
            throw LlmException("Network error: ${e.message}", -1)
        } finally {
            c.disconnect()
        }
    }
}
