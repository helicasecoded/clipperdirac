package com.clipperdirac.app

import android.app.Application
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppViewModel(app: Application) : AndroidViewModel(app) {
    var settings by mutableStateOf(SettingsStore.load(app))
        private set
    var videoUri by mutableStateOf<Uri?>(null)
        private set
    var videoName by mutableStateOf("")
    var running by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
    var progress by mutableFloatStateOf(0f)
    var logLines by mutableStateOf(listOf<String>())
    var projects by mutableStateOf(ProjectStore.load(app))
        private set

    private var job: Job? = null
    private val main = Handler(Looper.getMainLooper())

    private fun ui(block: () -> Unit) { main.post { block() } }
    private fun log(msg: String) = ui { logLines = (logLines + msg).takeLast(8) }
    private fun setStatus(text: String, p: Float) = ui { status = text; progress = p.coerceIn(0f, 1f) }
    private fun fail(msg: String) = ui { status = "❌ $msg"; logLines = (logLines + msg).takeLast(8) }

    fun update(s: Settings) {
        settings = s
        SettingsStore.save(getApplication(), s)
    }

    fun pickVideo(uri: Uri) {
        videoUri = uri
        videoName = try {
            getApplication<Application>().contentResolver.query(uri, null, null, null, null)?.use {
                if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
            } ?: "video"
        } catch (_: Exception) { "video" }
    }

    fun stop() {
        job?.cancel()
        status = "Roka gaya"
    }

    fun start() {
        if (job?.isActive == true) return
        val app = getApplication<Application>()
        running = true
        logLines = emptyList()
        KeepAliveService.start(app)
        job = viewModelScope.launch {
            try {
                pipeline()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(e.message ?: e.toString())
            } finally {
                KeepAliveService.stop(app)
                running = false
            }
        }
    }

    private suspend fun pipeline() {
        val ctx = getApplication<Application>()
        val uri = videoUri
        if (uri == null) { fail("Pehle video chuno"); return }
        val s = settings
        val router = LlmRouter(s) { log(it) }
        if (router.isEmpty) { fail("Kam se kam ek API key daalo (Gemini ya Grok)"); return }

        setStatus("Speech model check ho raha hai...", 0.01f)
        val modelDir = withContext(Dispatchers.IO) {
            Transcriber.ensureModel(ctx, s.language) { p ->
                setStatus("Speech model download ${(p * 100).toInt()}% (sirf pehli baar)", 0.01f + 0.04f * p.toFloat())
            }
        }

        setStatus("Video sun raha hu (transcription)...", 0.05f)
        val tr = withContext(Dispatchers.IO) {
            val j = currentCoroutineContext()[Job]!!
            Transcriber.transcribe(
                ctx, uri, modelDir,
                { p -> setStatus("Transcription ${(p * 100).toInt()}%", 0.05f + 0.35f * p.toFloat()) },
                { !j.isActive }
            )
        }
        if (tr.words.size < 20) { fail("Video me bolne wali awaaz bahut kam mili. Language sahi chuni?"); return }
        log("${tr.words.size} words transcribe hue")

        setStatus("AI best moments dhundh raha hai...", 0.42f)
        val cands = withContext(Dispatchers.IO) {
            ClipPlanner.plan(tr, s, router, { log(it) }, { p -> setStatus("AI selection...", 0.42f + 0.12f * p) })
        }
        if (cands.isEmpty()) { fail("Koi acchi clip nahi mili. Length setting badal ke try karo."); return }
        log("${cands.size} clips select hui")

        val folder = slug(videoName) + "_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        val records = ArrayList<ClipRecord>()
        val srcUri = uri
        for ((i, c) in cands.withIndex()) {
            val base = 0.55f + 0.45f * i / cands.size
            val span = 0.45f / cands.size
            setStatus("Clip ${i + 1}/${cands.size} edit ho rahi hai...", base)
            try {
                val plan = ClipPlanner.buildEditPlan(tr.words, c, s)
                val tmp = File(ctx.cacheDir, "clip_${i + 1}.mp4")
                tmp.delete()
                Renderer.render(ctx, srcUri, plan, s, tmp) { p ->
                    setStatus("Clip ${i + 1}/${cands.size} edit ${(p * 100).toInt()}%", base + span * p)
                }
                val name = String.format(Locale.US, "clip_%02d_%s.mp4", i + 1, slug(c.title, "clip"))
                val saved = withContext(Dispatchers.IO) {
                    Gallery.save(ctx, tmp, folder, name).also { tmp.delete() }
                }
                records.add(ClipRecord(c.title, c.reason, saved.toString(), name, plan.duration))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log("Clip ${i + 1} fail: ${e.message?.take(140)}")
            }
        }
        if (records.isEmpty()) { fail("Koi clip export nahi ho payi. Log dekho."); return }
        projects = ProjectStore.add(ctx, Project(folder, records))
        setStatus("✅ ${records.size} clips ready: Movies/Clipperdirac/$folder", 1f)
    }
}
