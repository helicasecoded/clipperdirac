package com.clipperdirac.app

import android.app.Application
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

data class VideoItem(val uri: Uri, val name: String)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    var settings by mutableStateOf(SettingsStore.load(app))
        private set
    var videos by mutableStateOf(listOf<VideoItem>())
        private set
    var running by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
    var progress by mutableFloatStateOf(0f)
    var logLines by mutableStateOf(listOf<String>())
    var projects by mutableStateOf(ProjectStore.load(app))
        private set
    var campaigns by mutableStateOf(CampaignStore.load(app))
        private set

    private var job: Job? = null
    private val main = Handler(Looper.getMainLooper())

    private fun ui(block: () -> Unit) { main.post { block() } }
    private fun log(msg: String) = ui { logLines = (logLines + msg).takeLast(8) }
    private fun setStatus(text: String, p: Float) = ui { status = text; progress = p.coerceIn(0f, 1f) }
    private fun fail(msg: String) = ui { status = "❌ $msg"; logLines = (logLines + msg).takeLast(8) }

    fun update(s: Settings) {
        settings = s
        SettingsStore.save(getApplication(), s)
    }

    // ---------------------------------------------------------- videos
    fun addVideos(uris: List<Uri>) {
        val app = getApplication<Application>()
        val added = uris.filter { u -> videos.none { it.uri == u } }.map { u ->
            val name = try {
                app.contentResolver.query(u, null, null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                } ?: "video"
            } catch (_: Exception) { "video" }
            VideoItem(u, name)
        }
        videos = videos + added
    }

    fun removeVideo(i: Int) {
        videos = videos.filterIndexed { idx, _ -> idx != i }
    }

    fun stop() {
        job?.cancel()
        status = "Roka gaya"
    }

    // --------------------------------------------------------- campaigns
    fun saveCampaign(c: Campaign) {
        val app = getApplication<Application>()
        val list = if (campaigns.any { it.id == c.id }) campaigns.map { if (it.id == c.id) c else it } else listOf(c) + campaigns
        campaigns = list
        CampaignStore.save(app, list)
    }

    fun deleteCampaign(id: Long) {
        campaigns = campaigns.filter { it.id != id }
        CampaignStore.save(getApplication(), campaigns)
    }

    // ------------------------------------------------------ library edits
    fun setViews(folder: String, index: Int, views: Long) {
        val rec = projects.firstOrNull { it.folder == folder }?.clips?.getOrNull(index) ?: return
        projects = ProjectStore.updateClip(getApplication(), folder, index, rec.copy(views = views))
    }

    fun deleteClip(folder: String, index: Int) {
        val app = getApplication<Application>()
        val rec = projects.firstOrNull { it.folder == folder }?.clips?.getOrNull(index) ?: return
        viewModelScope.launch {
            withContext(Dispatchers.IO) { Gallery.delete(app, rec.uri) }
            projects = ProjectStore.removeClip(app, folder, index)
        }
    }

    private fun buildHistory(): String {
        val all = projects.flatMap { it.clips }.filter { it.views > 0 }
        if (all.isEmpty()) return ""
        val sorted = all.sortedByDescending { it.views }
        val sb = StringBuilder()
        sorted.take(4).forEach {
            sb.append("GOOD (${it.views} views): ${it.headline.ifBlank { it.title }} | ${it.reason.take(100)}\n")
        }
        if (sorted.size > 4) sorted.takeLast(2).forEach {
            sb.append("WEAK (${it.views} views): ${it.headline.ifBlank { it.title }} | ${it.reason.take(100)}\n")
        }
        return sb.toString()
    }

    // ------------------------------------------------------------ start
    fun start() {
        if (job?.isActive == true) return
        if (videos.isEmpty()) { fail("Pehle video chuno"); return }
        val app = getApplication<Application>()
        running = true
        logLines = emptyList()
        KeepAliveService.start(app)
        job = viewModelScope.launch {
            try {
                val list = videos
                for ((i, v) in list.withIndex()) {
                    log("Video ${i + 1}/${list.size}: ${v.name}")
                    try {
                        pipeline(v, i, list.size)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        fail(e.message ?: e.toString())
                    }
                }
            } finally {
                KeepAliveService.stop(app)
                running = false
            }
        }
    }

    /** Plan banao -> caption (Hinglish/edit) -> face track -> render. Returns (final plan, temp file). */
    private suspend fun buildAndRender(
        uri: Uri,
        cand: Cand,
        words: List<Word>,
        router: LlmRouter?,
        capsText: String?,
        onProgress: (Float) -> Unit,
    ): Pair<EditPlan, File> {
        val ctx = getApplication<Application>()
        val s = settings
        val plan0 = ClipPlanner.buildEditPlan(words, cand, s)
        var caps = plan0.caps
        if (capsText != null) {
            caps = ClipPlanner.applyCapsText(caps, capsText)
        } else if (s.language == "hi" && s.hindiScript == "roman" && router != null && caps.isNotEmpty()) {
            val r = withContext(Dispatchers.IO) { ClipPlanner.romanize(caps.map { it.w }, router) { log(it) } }
            if (r != null && r.size == caps.size) {
                caps = caps.mapIndexed { i, c -> c.copy(w = r[i].ifBlank { c.w }) }
            } else {
                log("Hinglish convert nahi hua, Devanagari rahega")
            }
        }
        val plan = plan0.copy(caps = caps)
        val face = if (s.faceFollow && s.layout == "fill") {
            withContext(Dispatchers.IO) {
                try { FaceAnalyzer.analyze(ctx, uri, cand.start, cand.end) } catch (e: Exception) { null }
            }
        } else null
        val tmp = File(ctx.cacheDir, "clip_${System.nanoTime()}.mp4")
        Renderer.render(ctx, uri, plan, cand.headline.ifBlank { cand.title }, s, face, tmp, onProgress)
        return plan to tmp
    }

    private suspend fun pipeline(item: VideoItem, idx: Int, total: Int) {
        val ctx = getApplication<Application>()
        val uri = item.uri
        val s = settings
        val base = idx.toFloat() / total
        val span = 1f / total
        val prefix = if (total > 1) "[${idx + 1}/$total] " else ""
        fun sp(text: String, p: Float) = setStatus(prefix + text, base + span * p)

        val router = LlmRouter(s) { log(it) }
        if (router.isEmpty) { fail("Settings me kam se kam ek API key daalo (Gemini ya Grok)"); return }

        sp("Speech model check ho raha hai...", 0.01f)
        val modelDir = withContext(Dispatchers.IO) {
            Transcriber.ensureModel(ctx, s.language) { p ->
                sp("Speech model download ${(p * 100).toInt()}% (sirf pehli baar)", 0.01f + 0.04f * p.toFloat())
            }
        }

        sp("Video sun raha hu (transcription)...", 0.05f)
        val tr = withContext(Dispatchers.IO) {
            val j = currentCoroutineContext()[Job]!!
            Transcriber.transcribe(
                ctx, uri, modelDir,
                { p -> sp("Transcription ${(p * 100).toInt()}%", 0.05f + 0.35f * p.toFloat()) },
                { !j.isActive }
            )
        }
        if (tr.words.size < 20) { fail("Video me bolne wali awaaz bahut kam mili. Language sahi chuni?"); return }
        log("${tr.words.size} words transcribe hue")

        val history = buildHistory()
        val cands = withContext(Dispatchers.IO) {
            ClipPlanner.plan(tr, s, router, { log(it) }, { msg, p -> sp(msg, 0.42f + 0.13f * p) }, history)
        }
        if (cands.isEmpty()) { fail("Koi acchi clip nahi mili. Length ya instruction badal ke try karo."); return }
        log("${cands.size} clips select hui")

        val folder = slug(item.name) + "_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        val records = ArrayList<ClipRecord>()
        for ((i, c) in cands.withIndex()) {
            val b = 0.55f + 0.45f * i / cands.size
            val sSpan = 0.45f / cands.size
            sp("Clip ${i + 1}/${cands.size} edit ho rahi hai...", b)
            try {
                val (plan, tmp) = buildAndRender(uri, c, tr.words, router, null) { p ->
                    sp("Clip ${i + 1}/${cands.size} edit ${(p * 100).toInt()}%", b + sSpan * p)
                }
                val name = String.format(Locale.US, "clip_%02d_%s.mp4", i + 1, slug(c.title, "clip"))
                val saved = withContext(Dispatchers.IO) {
                    Gallery.save(ctx, tmp, folder, name).also { tmp.delete() }
                }
                records.add(
                    ClipRecord(
                        title = c.title, reason = c.reason, uri = saved.toString(), name = name, dur = plan.duration,
                        ytTitle = c.ytTitle, ytDesc = c.ytDesc, igCaption = c.igCaption, hashtags = c.hashtags,
                        start = c.start, end = c.end, remove = RemoveCodec.encode(c.remove),
                        hookS = c.hookS, hookE = c.hookE, headline = c.headline,
                        capsText = plan.caps.joinToString(" ") { it.w }, score = c.score,
                    )
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log("Clip ${i + 1} fail: ${e.message?.take(140)}")
            }
        }
        if (records.isEmpty()) { fail("Koi clip export nahi ho payi. Log dekho."); return }
        withContext(Dispatchers.IO) { ProjectStore.saveWords(ctx, folder, tr.words) }
        projects = ProjectStore.add(ctx, Project(folder, uri.toString(), records))
        setStatus("✅ ${records.size} clips ready (Library tab me dekho)", 1f)
    }

    // --------------------------------------------------------- re-render
    fun rerender(folder: String, index: Int, start: Double, end: Double, capsText: String, headline: String) {
        if (job?.isActive == true) return
        val app = getApplication<Application>()
        running = true
        logLines = emptyList()
        KeepAliveService.start(app)
        job = viewModelScope.launch {
            try {
                val proj = projects.firstOrNull { it.folder == folder }
                    ?: throw IllegalStateException("Project nahi mila")
                val rec = proj.clips.getOrNull(index) ?: throw IllegalStateException("Clip nahi mili")
                val words = withContext(Dispatchers.IO) { ProjectStore.loadWords(app, folder) }
                if (words.isEmpty()) throw IllegalStateException("Transcript nahi mila. Video dobara generate karo.")
                val uri = Uri.parse(proj.source)
                val same = abs(start - rec.start) < 0.01 && abs(end - rec.end) < 0.01
                val cand = Cand(
                    start = start, end = end, title = rec.title, reason = rec.reason, score = rec.score,
                    remove = RemoveCodec.decode(rec.remove), headline = headline,
                    hookS = if (same) rec.hookS else -1.0, hookE = if (same) rec.hookE else -1.0,
                )
                setStatus("Clip dobara ban rahi hai...", 0.05f)
                val (plan, tmp) = buildAndRender(uri, cand, words, null, capsText) { p ->
                    setStatus("Re-render ${(p * 100).toInt()}%", 0.1f + 0.85f * p)
                }
                val name = String.format(
                    Locale.US, "clip_%02d_%s_%d.mp4", index + 1, slug(rec.title, "clip"), System.currentTimeMillis() % 10000
                )
                val saved = withContext(Dispatchers.IO) { Gallery.save(app, tmp, folder, name).also { tmp.delete() } }
                withContext(Dispatchers.IO) { Gallery.delete(app, rec.uri) }
                val newRec = rec.copy(
                    uri = saved.toString(), name = name, dur = plan.duration, start = start, end = end,
                    headline = headline, capsText = plan.caps.joinToString(" ") { it.w },
                )
                projects = ProjectStore.updateClip(app, folder, index, newRec)
                setStatus("✅ Clip update ho gayi", 1f)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(e.message ?: e.toString())
            } finally {
                KeepAliveService.stop(app)
                running = false
            }
        }
    }
}
