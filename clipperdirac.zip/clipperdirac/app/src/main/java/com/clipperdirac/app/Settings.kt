package com.clipperdirac.app

import android.content.Context

data class Settings(
    val keys: String = "",           // jitni chahe keys, ek line me ek (Gemini "AIza..." / Grok "xai-...")
    val geminiModel: String = "",    // khali = auto (gemini-flash-latest)
    val grokModel: String = "",      // khali = auto (newest fast model)
    val language: String = "en",     // video me bolne ki language
    val hindiScript: String = "roman", // roman = Hinglish, dev = Devanagari (language=hi ke liye)
    val outLang: String = "same",    // title/caption language: same | en
    val handle: String = "",
    val creator: String = "",
    val instruction: String = "",    // AI ke liye custom instruction
    val analyst: Boolean = true,
    val coldOpen: Boolean = true,
    val clips: Int = 5,
    val minSec: Int = 30,
    val maxSec: Int = 60,
    val cutPauses: Boolean = true,
    val zoom: Boolean = true,
    val captions: Boolean = true,
    val captionStyle: String = "classic",
    val headline: Boolean = false,   // upar bada headline text (default band)
    val layout: String = "fill",     // fill | fit
    val faceFollow: Boolean = true,  // face follow + zaroorat par face zoom
    val sfx: Boolean = true,
    val musicUri: String = "",
    val musicVol: Float = 0.10f,
    val duck: Boolean = true,        // bolte waqt music halka
    val logoUri: String = "",
    val quality: Int = 1080,         // 1080 | 720
)

object SettingsStore {
    private const val P = "clipperdirac"

    fun load(ctx: Context): Settings {
        val p = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)
        val d = Settings()
        val keys = p.getString("keys", null)
            ?: listOf("gemini1", "gemini2", "grok").mapNotNull { p.getString(it, null) }
                .filter { it.isNotBlank() }.joinToString("\n")
        return Settings(
            keys = keys,
            geminiModel = p.getString("geminiModel", d.geminiModel) ?: "",
            grokModel = p.getString("grokModel", d.grokModel) ?: "",
            language = p.getString("language", d.language) ?: "en",
            hindiScript = p.getString("hindiScript", d.hindiScript) ?: "roman",
            outLang = p.getString("outLang", d.outLang) ?: "same",
            handle = p.getString("handle", d.handle) ?: "",
            creator = p.getString("creator", d.creator) ?: "",
            instruction = p.getString("instruction", d.instruction) ?: "",
            analyst = p.getBoolean("analyst", d.analyst),
            coldOpen = p.getBoolean("coldOpen", d.coldOpen),
            clips = p.getInt("clips", d.clips),
            minSec = p.getInt("minSec", d.minSec),
            maxSec = p.getInt("maxSec", d.maxSec),
            cutPauses = p.getBoolean("cutPauses", d.cutPauses),
            zoom = p.getBoolean("zoom", d.zoom),
            captions = p.getBoolean("captions", d.captions),
            captionStyle = p.getString("captionStyle", d.captionStyle) ?: "classic",
            headline = p.getBoolean("headline", d.headline),
            layout = p.getString("layout", d.layout) ?: "fill",
            faceFollow = p.getBoolean("faceFollow", d.faceFollow),
            sfx = p.getBoolean("sfx", d.sfx),
            musicUri = p.getString("musicUri", d.musicUri) ?: "",
            musicVol = p.getFloat("musicVol", d.musicVol),
            duck = p.getBoolean("duck", d.duck),
            logoUri = p.getString("logoUri", d.logoUri) ?: "",
            quality = p.getInt("quality", d.quality),
        )
    }

    fun save(ctx: Context, s: Settings) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
            .putString("keys", s.keys)
            .putString("geminiModel", s.geminiModel)
            .putString("grokModel", s.grokModel)
            .putString("language", s.language)
            .putString("hindiScript", s.hindiScript)
            .putString("outLang", s.outLang)
            .putString("handle", s.handle)
            .putString("creator", s.creator)
            .putString("instruction", s.instruction)
            .putBoolean("analyst", s.analyst)
            .putBoolean("coldOpen", s.coldOpen)
            .putInt("clips", s.clips)
            .putInt("minSec", s.minSec)
            .putInt("maxSec", s.maxSec)
            .putBoolean("cutPauses", s.cutPauses)
            .putBoolean("zoom", s.zoom)
            .putBoolean("captions", s.captions)
            .putString("captionStyle", s.captionStyle)
            .putBoolean("headline", s.headline)
            .putString("layout", s.layout)
            .putBoolean("faceFollow", s.faceFollow)
            .putBoolean("sfx", s.sfx)
            .putString("musicUri", s.musicUri)
            .putFloat("musicVol", s.musicVol)
            .putBoolean("duck", s.duck)
            .putString("logoUri", s.logoUri)
            .putInt("quality", s.quality)
            .apply()
    }
}
