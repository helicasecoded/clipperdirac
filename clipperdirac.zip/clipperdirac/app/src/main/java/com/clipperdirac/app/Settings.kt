package com.clipperdirac.app

import android.content.Context

data class Settings(
    val keys: String = "",          // jitni chahe keys, ek line me ek (Gemini "AIza..." / Grok "xai-...")
    val geminiModel: String = "",   // khali = auto (gemini-flash-latest)
    val grokModel: String = "",     // khali = auto (newest fast model)
    val language: String = "en",    // video me bolne ki language
    val outLang: String = "same",   // title/caption language: same | en
    val handle: String = "",        // video pe likha aane wala handle/naam
    val creator: String = "",       // source creator/channel ka naam (analysis ke liye)
    val analyst: Boolean = true,    // smart analysis + trend research
    val coldOpen: Boolean = true,   // sabse gripping line pehle
    val clips: Int = 5,
    val minSec: Int = 30,
    val maxSec: Int = 60,
    val cutPauses: Boolean = true,
    val zoom: Boolean = true,
    val captions: Boolean = true,
    val headline: Boolean = true,
    val sfx: Boolean = true,
    val musicUri: String = "",
    val musicVol: Float = 0.10f,
)

object SettingsStore {
    private const val P = "clipperdirac"

    fun load(ctx: Context): Settings {
        val p = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)
        val d = Settings()
        val keys = p.getString("keys", null)
            ?: listOf("gemini1", "gemini2", "grok").mapNotNull { p.getString(it, null) }
                .filter { it.isNotBlank() }.joinToString("\n")
        return Settings(
            keys = keys,
            geminiModel = p.getString("geminiModel", d.geminiModel) ?: "",
            grokModel = p.getString("grokModel", d.grokModel) ?: "",
            language = p.getString("language", d.language) ?: "en",
            outLang = p.getString("outLang", d.outLang) ?: "same",
            handle = p.getString("handle", d.handle) ?: "",
            creator = p.getString("creator", d.creator) ?: "",
            analyst = p.getBoolean("analyst", d.analyst),
            coldOpen = p.getBoolean("coldOpen", d.coldOpen),
            clips = p.getInt("clips", d.clips),
            minSec = p.getInt("minSec", d.minSec),
            maxSec = p.getInt("maxSec", d.maxSec),
            cutPauses = p.getBoolean("cutPauses", d.cutPauses),
            zoom = p.getBoolean("zoom", d.zoom),
            captions = p.getBoolean("captions", d.captions),
            headline = p.getBoolean("headline", d.headline),
            sfx = p.getBoolean("sfx", d.sfx),
            musicUri = p.getString("musicUri", d.musicUri) ?: "",
            musicVol = p.getFloat("musicVol", d.musicVol),
        )
    }

    fun save(ctx: Context, s: Settings) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
            .putString("keys", s.keys)
            .putString("geminiModel", s.geminiModel)
            .putString("grokModel", s.grokModel)
            .putString("language", s.language)
            .putString("outLang", s.outLang)
            .putString("handle", s.handle)
            .putString("creator", s.creator)
            .putBoolean("analyst", s.analyst)
            .putBoolean("coldOpen", s.coldOpen)
            .putInt("clips", s.clips)
            .putInt("minSec", s.minSec)
            .putInt("maxSec", s.maxSec)
            .putBoolean("cutPauses", s.cutPauses)
            .putBoolean("zoom", s.zoom)
            .putBoolean("captions", s.captions)
            .putBoolean("headline", s.headline)
            .putBoolean("sfx", s.sfx)
            .putString("musicUri", s.musicUri)
            .putFloat("musicVol", s.musicVol)
            .apply()
    }
}
