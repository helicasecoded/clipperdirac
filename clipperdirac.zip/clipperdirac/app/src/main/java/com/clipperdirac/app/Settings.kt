package com.clipperdirac.app

import android.content.Context

data class Settings(
    val gemini1: String = "",
    val gemini2: String = "",
    val grok: String = "",
    val geminiModel: String = "",   // khali = auto (gemini-flash-latest)
    val grokModel: String = "",     // khali = auto
    val language: String = "en",    // en | hi
    val clips: Int = 5,
    val minSec: Int = 30,
    val maxSec: Int = 60,
    val cutPauses: Boolean = true,
    val zoom: Boolean = true,
    val captions: Boolean = true,
    val sfx: Boolean = true,
    val musicUri: String = "",
    val musicVol: Float = 0.10f,
)

object SettingsStore {
    private const val P = "clipperdirac"

    fun load(ctx: Context): Settings {
        val p = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)
        val d = Settings()
        return Settings(
            gemini1 = p.getString("gemini1", d.gemini1) ?: "",
            gemini2 = p.getString("gemini2", d.gemini2) ?: "",
            grok = p.getString("grok", d.grok) ?: "",
            geminiModel = p.getString("geminiModel", d.geminiModel) ?: "",
            grokModel = p.getString("grokModel", d.grokModel) ?: "",
            language = p.getString("language", d.language) ?: "en",
            clips = p.getInt("clips", d.clips),
            minSec = p.getInt("minSec", d.minSec),
            maxSec = p.getInt("maxSec", d.maxSec),
            cutPauses = p.getBoolean("cutPauses", d.cutPauses),
            zoom = p.getBoolean("zoom", d.zoom),
            captions = p.getBoolean("captions", d.captions),
            sfx = p.getBoolean("sfx", d.sfx),
            musicUri = p.getString("musicUri", d.musicUri) ?: "",
            musicVol = p.getFloat("musicVol", d.musicVol),
        )
    }

    fun save(ctx: Context, s: Settings) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
            .putString("gemini1", s.gemini1)
            .putString("gemini2", s.gemini2)
            .putString("grok", s.grok)
            .putString("geminiModel", s.geminiModel)
            .putString("grokModel", s.grokModel)
            .putString("language", s.language)
            .putInt("clips", s.clips)
            .putInt("minSec", s.minSec)
            .putInt("maxSec", s.maxSec)
            .putBoolean("cutPauses", s.cutPauses)
            .putBoolean("zoom", s.zoom)
            .putBoolean("captions", s.captions)
            .putBoolean("sfx", s.sfx)
            .putString("musicUri", s.musicUri)
            .putFloat("musicVol", s.musicVol)
            .apply()
    }
}
