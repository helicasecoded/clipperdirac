@file:OptIn(UnstableApi::class)

package com.clipperdirac.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Music ki awaaz kam karne ke liye simple gain. */
class GainProcessor(private val gain: Float) : BaseAudioProcessor() {
    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val out = replaceOutputBuffer(inputBuffer.remaining())
        while (inputBuffer.remaining() >= 2) {
            val v = (inputBuffer.getShort() * gain).toInt().coerceIn(-32768, 32767)
            out.putShort(v.toShort())
        }
        out.flip()
    }
}

class CapChunk(val words: List<CapWord>) {
    val start: Double = words.first().s
    val end: Double = words.last().e + 0.15
}

/** Bade word-by-word captions: bolne wala shabd yellow me. Full-frame transparent bitmap. */
class CaptionOverlay(private val chunks: List<CapChunk>) : BitmapOverlay() {
    private val w = 1080
    private val h = 1920
    private var lastKey = Int.MIN_VALUE
    private var lastBmp: Bitmap? = null
    private val blank: Bitmap by lazy { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val t = presentationTimeUs / 1_000_000.0
        var ci = -1
        var wi = 0
        for (i in chunks.indices.reversed()) {
            val c = chunks[i]
            if (t >= c.start && t <= c.end) {
                ci = i
                for (j in c.words.indices) if (c.words[j].s <= t) wi = j
                break
            }
        }
        val key = if (ci < 0) -1 else ci * 16 + wi
        val cached = lastBmp
        if (cached != null && key == lastKey) return cached
        val bmp = if (ci < 0) blank else draw(chunks[ci], wi)
        lastKey = key
        lastBmp = bmp
        return bmp
    }

    private fun draw(chunk: CapChunk, active: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val face = Typeface.create(Typeface.DEFAULT, 900, false)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = face; textSize = 92f }
        val words = chunk.words.map { it.w.uppercase() }
        val gap0 = 92f * 0.28f
        var total = words.sumOf { fill.measureText(it).toDouble() } + gap0 * (words.size - 1)
        val maxW = w * 0.9
        val size = if (total > maxW) (92f * (maxW / total)).toFloat() else 92f
        fill.textSize = size
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = face; textSize = size; style = Paint.Style.STROKE
            strokeWidth = size * 0.16f; strokeJoin = Paint.Join.ROUND; color = Color.BLACK
        }
        val gap = size * 0.28f
        total = words.sumOf { fill.measureText(it).toDouble() } + gap * (words.size - 1)
        var x = ((w - total) / 2).toFloat()
        val y = h * 0.68f
        for ((i, word) in words.withIndex()) {
            canvas.drawText(word, x, y, stroke)
            fill.color = if (i == active) Color.rgb(255, 230, 0) else Color.WHITE
            canvas.drawText(word, x, y, fill)
            x += fill.measureText(word) + gap
        }
        return bmp
    }
}

object Renderer {
    private fun zoomAt(bounds: List<Double>, t: Double): Float {
        var idx = 0
        for (i in bounds.indices) {
            if (bounds[i] <= t) idx = i else break
        }
        val segEnd = if (idx + 1 < bounds.size) bounds[idx + 1] else bounds[idx] + 3.4
        val p = ((t - bounds[idx]) / maxOf(segEnd - bounds[idx], 0.1)).coerceIn(0.0, 1.0).toFloat()
        val base = if (idx % 2 == 1) 1.16f else 1.0f
        return base + 0.05f * p
    }

    private fun chunkCaps(caps: List<CapWord>): List<CapChunk> {
        val out = ArrayList<CapChunk>()
        var cur = ArrayList<CapWord>()
        for ((i, c) in caps.withIndex()) {
            cur.add(c)
            val next = caps.getOrNull(i + 1)
            if (cur.size == 3 || next == null || next.s - c.e > 0.5) {
                out.add(CapChunk(cur)); cur = ArrayList()
            }
        }
        return out
    }

    /** Whoosh + soft pop ka audio track (WAV), har cut-zoom pe. */
    private fun writeSfx(file: File, duration: Double, hits: List<Double>) {
        val sr = 44100
        val n = ((duration + 0.5) * sr).toInt()
        val pcm = IntArray(n)
        val rnd = java.util.Random(7)
        for (h in hits) {
            val start = (maxOf(h - 0.18, 0.0) * sr).toInt()
            val len = (0.5 * sr).toInt()
            var y = 0f
            for (i in 0 until len) {
                val idx = start + i
                if (idx >= n) break
                val p = i.toFloat() / len
                val env = if (p < 0.4f) p / 0.4f else (1f - p) / 0.6f
                val a = 0.04f + 0.55f * p
                y += a * ((rnd.nextFloat() * 2f - 1f) - y)
                pcm[idx] += (y * env * env * 1.6f * 32767f).toInt()
            }
            val popStart = (h * sr).toInt()
            val popLen = (0.16 * sr).toInt()
            for (i in 0 until popLen) {
                val idx = popStart + i
                if (idx >= n) break
                val p = i.toFloat() / popLen
                val v = Math.sin(2 * Math.PI * 85.0 * i / sr) * (1.0 - p) * (1.0 - p) * 0.55
                pcm[idx] += (v * 32767).toInt()
            }
        }
        val dataLen = n * 2
        val bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + dataLen).put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
            .putInt(sr).putInt(sr * 2).putShort(2).putShort(16)
        bb.put("data".toByteArray()).putInt(dataLen)
        for (v in pcm) bb.putShort(v.coerceIn(-32768, 32767).toShort())
        FileOutputStream(file).use { it.write(bb.array()) }
    }

    suspend fun render(
        ctx: Context,
        src: Uri,
        plan: EditPlan,
        s: Settings,
        out: File,
        onProgress: (Float) -> Unit,
    ) {
        val items = plan.ranges.map { r ->
            EditedMediaItem.Builder(
                MediaItem.Builder().setUri(src)
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs((r.s * 1000).toLong())
                            .setEndPositionMs((r.e * 1000).toLong())
                            .build()
                    ).build()
            ).build()
        }
        val vb = EditedMediaItemSequence.Builder(items[0])
        for (i in 1 until items.size) vb.addItem(items[i])
        val sequences = ArrayList<EditedMediaItemSequence>()
        sequences.add(vb.build())

        var sfxFile: File? = null
        if (s.sfx && plan.hits.isNotEmpty()) {
            val f = File(ctx.cacheDir, "sfx_${System.nanoTime()}.wav")
            writeSfx(f, plan.duration, plan.hits)
            sfxFile = f
            sequences.add(
                EditedMediaItemSequence.Builder(
                    EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(f))).build()
                ).build()
            )
        }
        if (s.musicUri.isNotBlank()) {
            val music = EditedMediaItem.Builder(MediaItem.fromUri(Uri.parse(s.musicUri)))
                .setRemoveVideo(true)
                .setEffects(Effects(listOf<AudioProcessor>(GainProcessor(s.musicVol)), emptyList<Effect>()))
                .build()
            sequences.add(EditedMediaItemSequence.Builder(music).setIsLooping(true).build())
        }

        val videoEffects = ArrayList<Effect>()
        videoEffects.add(
            Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
        )
        if (s.zoom) {
            val bounds = plan.zoomBounds
            videoEffects.add(MatrixTransformation { us ->
                val z = zoomAt(bounds, us / 1_000_000.0)
                Matrix().apply { postScale(z, z) }
            })
        }
        if (s.captions && plan.caps.isNotEmpty()) {
            val overlay = CaptionOverlay(chunkCaps(plan.caps))
            videoEffects.add(OverlayEffect(ImmutableList.of<TextureOverlay>(overlay)))
        }

        val composition = Composition.Builder(sequences)
            .setEffects(Effects(emptyList<AudioProcessor>(), videoEffects))
            .build()
        try {
            export(ctx, composition, out, onProgress)
        } finally {
            sfxFile?.delete()
        }
    }

    private suspend fun export(ctx: Context, composition: Composition, out: File, onProgress: (Float) -> Unit) =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<Unit> { cont ->
                val encoder = DefaultEncoderFactory.Builder(ctx)
                    .setRequestedVideoEncoderSettings(
                        VideoEncoderSettings.Builder().setBitrate(8_000_000).build()
                    ).build()
                val transformer = Transformer.Builder(ctx)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .setEncoderFactory(encoder)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (cont.isActive) cont.resume(Unit)
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException,
                        ) {
                            if (cont.isActive) cont.resumeWithException(exportException)
                        }
                    }).build()
                transformer.start(composition, out.absolutePath)

                val handler = Handler(Looper.getMainLooper())
                val holder = ProgressHolder()
                val poll = object : Runnable {
                    override fun run() {
                        if (!cont.isActive) return
                        if (transformer.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) {
                            onProgress(holder.progress / 100f)
                        }
                        handler.postDelayed(this, 500)
                    }
                }
                handler.post(poll)
                cont.invokeOnCancellation { handler.post { transformer.cancel() } }
            }
        }
}
