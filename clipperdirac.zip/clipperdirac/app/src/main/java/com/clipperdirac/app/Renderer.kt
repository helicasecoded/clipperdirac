@file:OptIn(UnstableApi::class)

package com.clipperdirac.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

// ------------------------------------------------------------------ audio
/** Music ki fixed awaaz. */
class GainProcessor(private val gain: Float) : BaseAudioProcessor() {
    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val out = replaceOutputBuffer(inputBuffer.remaining())
        while (inputBuffer.remaining() >= 2) {
            val v = (inputBuffer.getShort() * gain).toInt().coerceIn(-32768, 32767)
            out.putShort(v.toShort())
        }
        out.flip()
    }
}

/** Bolte waqt music halka (low), pause me thoda upar (high). */
class DuckingProcessor(
    private val speech: List<DoubleArray>,
    private val low: Float,
    private val high: Float,
) : BaseAudioProcessor() {
    private var rate = 44100
    private var ch = 2
    private var frame = 0L
    private var gain = high
    private var target = high

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        rate = inputAudioFormat.sampleRate
        ch = maxOf(inputAudioFormat.channelCount, 1)
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val out = replaceOutputBuffer(inputBuffer.remaining())
        while (inputBuffer.remaining() >= 2 * ch) {
            if (frame % 441L == 0L) {
                val t = frame.toDouble() / rate
                target = if (speech.any { t >= it[0] && t <= it[1] }) low else high
            }
            gain += (target - gain) * 0.0004f
            for (c in 0 until ch) {
                val v = (inputBuffer.getShort() * gain).toInt().coerceIn(-32768, 32767)
                out.putShort(v.toShort())
            }
            frame++
        }
        out.flip()
    }
}

// --------------------------------------------------------------- captions
data class CapStyle(
    val id: String,
    val label: String,
    val size: Float,
    val normal: Int,
    val active: Int,
    val stroke: Float,
    val box: Boolean,
    val boxColor: Int,
    val yFrac: Float,
    val upper: Boolean,
)

val CAP_STYLES = listOf(
    CapStyle("classic", "Classic", 92f, Color.WHITE, Color.rgb(255, 230, 0), 0.16f, false, 0, 0.68f, true),
    CapStyle("pop", "Green Pop", 100f, Color.WHITE, Color.rgb(57, 255, 20), 0.18f, false, 0, 0.64f, true),
    CapStyle("neon", "Neon", 92f, Color.rgb(0, 229, 255), Color.rgb(255, 64, 200), 0.14f, false, 0, 0.68f, true),
    CapStyle("box", "Boxed", 88f, Color.WHITE, Color.BLACK, 0.14f, true, Color.rgb(255, 230, 0), 0.68f, true),
    CapStyle("minimal", "Minimal", 70f, Color.WHITE, Color.rgb(170, 225, 255), 0.10f, false, 0, 0.74f, false),
)

fun capStyle(id: String): CapStyle = CAP_STYLES.firstOrNull { it.id == id } ?: CAP_STYLES[0]

class CapChunk(val words: List<CapWord>) {
    val start: Double = words.first().s
    val end: Double = words.last().e + 0.15
}

/** Word-by-word captions (full-frame transparent bitmap). */
class CaptionOverlay(private val chunks: List<CapChunk>, private val cs: CapStyle) : BitmapOverlay() {
    private val w = 1080
    private val h = 1920
    private var lastKey = Int.MIN_VALUE
    private var lastBmp: Bitmap? = null
    private val blank: Bitmap by lazy { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val t = presentationTimeUs / 1_000_000.0
        var ci = -1
        var wi = 0
        for (i in chunks.indices.reversed()) {
            val c = chunks[i]
            if (t >= c.start && t <= c.end) {
                ci = i
                for (j in c.words.indices) if (c.words[j].s <= t) wi = j
                break
            }
        }
        val key = if (ci < 0) -1 else ci * 16 + wi
        val cached = lastBmp
        if (cached != null && key == lastKey) return cached
        val bmp = if (ci < 0) blank else draw(chunks[ci], wi)
        lastKey = key
        lastBmp = bmp
        return bmp
    }

    private fun draw(chunk: CapChunk, active: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val face = Typeface.create(Typeface.DEFAULT, 900, false)
        val words = chunk.words.map { if (cs.upper) it.w.uppercase() else it.w }
        val base = cs.size
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.typeface = face
        fill.textSize = base
        var total = words.sumOf { fill.measureText(it).toDouble() } + base * 0.28 * (words.size - 1)
        val maxW = w * 0.9
        val size = if (total > maxW) (base * (maxW / total)).toFloat() else base
        fill.textSize = size
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
        stroke.typeface = face
        stroke.textSize = size
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = size * cs.stroke
        stroke.strokeJoin = Paint.Join.ROUND
        stroke.color = Color.BLACK
        val gap = size * 0.28f
        total = words.sumOf { fill.measureText(it).toDouble() } + gap * (words.size - 1)
        var x = ((w - total) / 2).toFloat()
        val y = h * cs.yFrac
        val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        boxPaint.color = cs.boxColor
        for ((i, word) in words.withIndex()) {
            val ww = fill.measureText(word)
            val boxed = cs.box && i == active
            if (boxed) {
                canvas.drawRoundRect(RectF(x - 16f, y - size * 0.95f, x + ww + 16f, y + size * 0.28f), 18f, 18f, boxPaint)
            } else {
                canvas.drawText(word, x, y, stroke)
            }
            fill.color = if (i == active) cs.active else cs.normal
            canvas.drawText(word, x, y, fill)
            x += ww + gap
        }
        return bmp
    }
}

/** Upar headline (optional), neeche handle, kone me logo. Poori clip me ek static bitmap. */
class StaticTextOverlay(
    private val headline: String,
    private val handle: String,
    private val logo: Bitmap?,
) : BitmapOverlay() {
    private val bmp: Bitmap by lazy { build() }

    override fun getBitmap(presentationTimeUs: Long): Bitmap = bmp

    private fun build(): Bitmap {
        val w = 1080
        val h = 1920
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val face = Typeface.create(Typeface.DEFAULT, 900, false)
        if (headline.isNotBlank()) {
            val text = headline.uppercase()
            val fillP = TextPaint(Paint.ANTI_ALIAS_FLAG)
            fillP.typeface = face
            fillP.textSize = 76f
            fillP.color = Color.WHITE
            val strokeP = TextPaint(fillP)
            strokeP.style = Paint.Style.STROKE
            strokeP.strokeWidth = 12f
            strokeP.strokeJoin = Paint.Join.ROUND
            strokeP.color = Color.BLACK
            fun layout(p: TextPaint) = StaticLayout.Builder.obtain(text, 0, text.length, p, 900)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setMaxLines(3).setEllipsize(TextUtils.TruncateAt.END).build()
            val lf = layout(fillP)
            val box = Paint(Paint.ANTI_ALIAS_FLAG)
            box.color = Color.argb(150, 0, 0, 0)
            c.drawRoundRect(RectF(50f, 200f, 1030f, 200f + lf.height + 60f), 36f, 36f, box)
            c.save()
            c.translate(90f, 230f)
            layout(strokeP).draw(c)
            lf.draw(c)
            c.restore()
        }
        if (handle.isNotBlank()) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.typeface = face
            p.textSize = 44f
            p.color = Color.argb(220, 255, 255, 255)
            p.textAlign = Paint.Align.CENTER
            val sp = Paint(p)
            sp.style = Paint.Style.STROKE
            sp.strokeWidth = 8f
            sp.color = Color.argb(200, 0, 0, 0)
            c.drawText(handle, w / 2f, 1790f, sp)
            c.drawText(handle, w / 2f, 1790f, p)
        }
        if (logo != null && logo.width > 0) {
            val tw = 190f
            val th = tw * logo.height / logo.width
            c.drawBitmap(logo, null, RectF(w - 50f - tw, 60f, w - 50f, 60f + th), Paint(Paint.FILTER_BITMAP_FLAG))
        }
        return b
    }
}

// ----------------------------------------------------------------- render
object Renderer {
    private fun zoomAt(bounds: List<Double>, t: Double): Float {
        var idx = 0
        for (i in bounds.indices) {
            if (bounds[i] <= t) idx = i else break
        }
        val segEnd = if (idx + 1 < bounds.size) bounds[idx + 1] else bounds[idx] + 3.4
        val p = ((t - bounds[idx]) / maxOf(segEnd - bounds[idx], 0.1)).coerceIn(0.0, 1.0).toFloat()
        val base = if (idx % 2 == 1) 1.16f else 1.0f
        return base + 0.05f * p
    }

    private fun compToSrc(ranges: List<Range>, t: Double): Double {
        var off = 0.0
        for (r in ranges) {
            if (t < off + r.len) return r.s + (t - off)
            off += r.len
        }
        return ranges.last().e
    }

    private fun chunkCaps(caps: List<CapWord>): List<CapChunk> {
        val out = ArrayList<CapChunk>()
        var cur = ArrayList<CapWord>()
        for ((i, c) in caps.withIndex()) {
            cur.add(c)
            val next = caps.getOrNull(i + 1)
            if (cur.size == 3 || next == null || next.s - c.e > 0.5) {
                out.add(CapChunk(cur)); cur = ArrayList()
            }
        }
        return out
    }

    private fun speechIntervals(caps: List<CapWord>): List<DoubleArray> {
        val out = ArrayList<DoubleArray>()
        for (c in caps) {
            val last = out.lastOrNull()
            if (last != null && c.s - 0.1 <= last[1] + 0.3) last[1] = c.e + 0.2
            else out.add(doubleArrayOf(maxOf(c.s - 0.1, 0.0), c.e + 0.2))
        }
        return out
    }

    /** Whoosh + soft pop ka audio track (WAV), har cut-zoom pe. */
    private fun writeSfx(file: File, duration: Double, hits: List<Double>) {
        val sr = 44100
        val n = ((duration + 0.5) * sr).toInt()
        val pcm = IntArray(n)
        val rnd = java.util.Random(7)
        for (h in hits) {
            val start = (maxOf(h - 0.18, 0.0) * sr).toInt()
            val len = (0.5 * sr).toInt()
            var y = 0f
            for (i in 0 until len) {
                val idx = start + i
                if (idx >= n) break
                val p = i.toFloat() / len
                val env = if (p < 0.4f) p / 0.4f else (1f - p) / 0.6f
                val a = 0.04f + 0.55f * p
                y += a * ((rnd.nextFloat() * 2f - 1f) - y)
                pcm[idx] += (y * env * env * 1.6f * 32767f).toInt()
            }
            val popStart = (h * sr).toInt()
            val popLen = (0.16 * sr).toInt()
            for (i in 0 until popLen) {
                val idx = popStart + i
                if (idx >= n) break
                val p = i.toFloat() / popLen
                val v = Math.sin(2 * Math.PI * 85.0 * i / sr) * (1.0 - p) * (1.0 - p) * 0.55
                pcm[idx] += (v * 32767).toInt()
            }
        }
        val dataLen = n * 2
        val bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + dataLen).put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
            .putInt(sr).putInt(sr * 2).putShort(2).putShort(16)
        bb.put("data".toByteArray()).putInt(dataLen)
        for (v in pcm) bb.putShort(v.coerceIn(-32768, 32767).toShort())
        FileOutputStream(file).use { it.write(bb.array()) }
    }

    private fun loadLogo(ctx: Context, uri: String): Bitmap? {
        if (uri.isBlank()) return null
        return try {
            ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) {
            null
        }
    }

    suspend fun render(
        ctx: Context,
        src: Uri,
        plan: EditPlan,
        headline: String,
        s: Settings,
        face: FaceTrack?,
        out: File,
        onProgress: (Float) -> Unit,
    ) {
        val items = plan.ranges.map { r ->
            EditedMediaItem.Builder(
                MediaItem.Builder().setUri(src)
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs((r.s * 1000).toLong())
                            .setEndPositionMs((r.e * 1000).toLong())
                            .build()
                    ).build()
            ).build()
        }
        val vb = EditedMediaItemSequence.Builder(items[0])
        for (i in 1 until items.size) vb.addItem(items[i])
        val sequences = ArrayList<EditedMediaItemSequence>()
        sequences.add(vb.build())

        var sfxFile: File? = null
        if (s.sfx && plan.hits.isNotEmpty()) {
            val f = File(ctx.cacheDir, "sfx_${System.nanoTime()}.wav")
            writeSfx(f, plan.duration, plan.hits)
            sfxFile = f
            sequences.add(
                EditedMediaItemSequence.Builder(
                    EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(f))).build()
                ).build()
            )
        }
        if (s.musicUri.isNotBlank()) {
            val proc: AudioProcessor = if (s.duck && plan.caps.isNotEmpty()) {
                DuckingProcessor(speechIntervals(plan.caps), s.musicVol * 0.5f, minOf(s.musicVol * 1.6f, 0.6f))
            } else GainProcessor(s.musicVol)
            val music = EditedMediaItem.Builder(MediaItem.fromUri(Uri.parse(s.musicUri)))
                .setRemoveVideo(true)
                .setEffects(Effects(listOf(proc), emptyList<Effect>()))
                .build()
            sequences.add(EditedMediaItemSequence.Builder(music).setIsLooping(true).build())
        }

        val ow = if (s.quality == 720) 720 else 1080
        val oh = if (s.quality == 720) 1280 else 1920
        val fit = s.layout == "fit"
        val videoEffects = ArrayList<Effect>()

        // Face follow: speaker ko 9:16 crop ke center me laata hai (aur zaroorat par zoom)
        if (face != null && !fit) {
            val ranges = plan.ranges
            videoEffects.add(MatrixTransformation { us ->
                val c = face.at(compToSrc(ranges, us / 1_000_000.0))
                val z = face.baseZoom
                val maxX = maxOf(1f - face.cw / z, 0f)
                val maxY = maxOf(1f - 1f / z, 0f)
                val cx = c[0].coerceIn(-maxX, maxX)
                val cy = (c[1] - 0.15f).coerceIn(-maxY, maxY)
                Matrix().apply { postTranslate(-cx, -cy); postScale(z, z) }
            })
        }
        videoEffects.add(
            Presentation.createForWidthAndHeight(
                ow, oh,
                if (fit) Presentation.LAYOUT_SCALE_TO_FIT else Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
            )
        )
        if (s.zoom) {
            val bounds = plan.zoomBounds
            videoEffects.add(MatrixTransformation { us ->
                val z = zoomAt(bounds, us / 1_000_000.0)
                Matrix().apply { postScale(z, z) }
            })
        }

        val logo = withContext(Dispatchers.IO) { loadLogo(ctx, s.logoUri) }
        val overlays = ImmutableList.builder<TextureOverlay>()
        var overlayCount = 0
        val topText = if (s.headline) headline else ""
        if (topText.isNotBlank() || s.handle.isNotBlank() || logo != null) {
            overlays.add(StaticTextOverlay(topText, s.handle.trim(), logo))
            overlayCount++
        }
        if (s.captions && plan.caps.isNotEmpty()) {
            overlays.add(CaptionOverlay(chunkCaps(plan.caps), capStyle(s.captionStyle)))
            overlayCount++
        }
        if (overlayCount > 0) videoEffects.add(OverlayEffect(overlays.build()))

        val composition = Composition.Builder(sequences)
            .setEffects(Effects(emptyList<AudioProcessor>(), videoEffects))
            .build()
        try {
            export(ctx, composition, out, if (s.quality == 720) 5_000_000 else 8_000_000, onProgress)
        } finally {
            sfxFile?.delete()
        }
    }

    private suspend fun export(
        ctx: Context,
        composition: Composition,
        out: File,
        bitrate: Int,
        onProgress: (Float) -> Unit,
    ) = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<Unit> { cont ->
            val encoder = DefaultEncoderFactory.Builder(ctx)
                .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                .build()
            val transformer = Transformer.Builder(ctx)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(encoder)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (cont.isActive) cont.resume(Unit)
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException,
                    ) {
                        if (cont.isActive) cont.resumeWithException(exportException)
                    }
                }).build()
            transformer.start(composition, out.absolutePath)

            val handler = Handler(Looper.getMainLooper())
            val holder = ProgressHolder()
            val poll = object : Runnable {
                override fun run() {
                    if (!cont.isActive) return
                    if (transformer.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) {
                        onProgress(holder.progress / 100f)
                    }
                    handler.postDelayed(this, 500)
                }
            }
            handler.post(poll)
            cont.invokeOnCancellation { handler.post { transformer.cancel() } }
        }
    }
}
