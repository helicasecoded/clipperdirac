package com.clipperdirac.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil

data class Cand(
    val start: Double,
    val end: Double,
    val title: String,
    val reason: String,
    val score: Double,
    val remove: List<DoubleArray>,
)

data class Range(val s: Double, val e: Double) {
    val len: Double get() = e - s
}

data class CapWord(val w: String, val s: Double, val e: Double)

data class EditPlan(
    val ranges: List<Range>,        // source video ke keep-hisse
    val duration: Double,           // final clip length
    val caps: List<CapWord>,        // captions (final timeline)
    val zoomBounds: List<Double>,   // zoom/cut boundaries (final timeline)
    val hits: List<Double>,         // whoosh timings (final timeline)
)

object ClipPlanner {
    private val FILLERS = setOf(
        "um", "umm", "uh", "uhh", "uhm", "er", "erm", "hmm", "hm", "mm", "mmm", "ah", "ahh", "eh", "huh",
        "हम्म", "हम", "अं", "अम्म", "उम्म", "अह"
    )
    private const val MAX_KEEP_GAP = 0.35   // isse lamba pause kat jayega
    private const val ZOOM_STEP = 3.4

    private val PROMPT = """
You are a top short-form video editor (Reels, YouTube Shorts, TikTok) who turns long videos into viral clips.
The transcript may be English, Hindi or Hinglish. Write titles in the same language/script as the transcript.

This window covers {ws}s to {we}s of a {total}s video. Pick up to {k} BEST moments from this window.

Every clip MUST:
- Be between {mn} and {mx} seconds long.
- OPEN with a strong hook in the first 3 seconds (bold claim, question, surprising fact, conflict, story start). If the moment has no hook, start a few sentences later where the hook begins.
- Be self-contained and to the point: setup then payoff. End on a complete thought or punchline, never mid-sentence.
- Skip intros, greetings, sponsor reads, rambling, repeated points, small talk.
- Include "remove": sub-ranges INSIDE the clip that are useless (restarts, repeated sentences, tangents, thinking aloud) so the clip stays tight. Use exact times from the transcript. Can be empty.
- Get "score" 1-10 for viral potential (retention, emotion, shareability).

Return ONLY a JSON array, no other text:
[{"start":123.4,"end":170.0,"title":"short catchy title","reason":"why it will perform","score":8,"remove":[[130.2,133.0]]}]

TRANSCRIPT (seconds):
{transcript}
""".trimIndent()

    fun plan(
        tr: TranscriptResult,
        s: Settings,
        router: LlmRouter,
        log: (String) -> Unit,
        progress: (Float) -> Unit,
    ): List<Cand> {
        val total = tr.segs.maxOf { it.e }
        val winLen = 720.0
        val overlap = 45.0
        val starts = ArrayList<Double>()
        var t = 0.0
        do {
            starts.add(t)
            t += winLen - overlap
        } while (t < total - 60.0)
        val k = ceil(s.clips * 2.0 / starts.size).toInt().coerceIn(2, 6)

        val all = ArrayList<Cand>()
        var okWindows = 0
        for ((i, ws) in starts.withIndex()) {
            val we = ws + winLen
            val lines = tr.segs.filter { it.e > ws && it.s < we }
                .joinToString("\n") { String.format(Locale.US, "[%.1f-%.1f] %s", it.s, it.e, it.t) }
            if (lines.isBlank()) continue
            progress(i.toFloat() / starts.size)
            val prompt = PROMPT
                .replace("{ws}", ws.toInt().toString())
                .replace("{we}", minOf(we, total).toInt().toString())
                .replace("{total}", total.toInt().toString())
                .replace("{k}", k.toString())
                .replace("{mn}", s.minSec.toString())
                .replace("{mx}", s.maxSec.toString())
                .replace("{transcript}", lines)
            try {
                val arr = parseArray(router.generateJson(prompt))
                var n = 0
                for (j in 0 until arr.length()) {
                    val o = arr.optJSONObject(j) ?: continue
                    val rem = ArrayList<DoubleArray>()
                    val ra = o.optJSONArray("remove")
                    if (ra != null) for (r in 0 until ra.length()) {
                        val pair = ra.optJSONArray(r) ?: continue
                        if (pair.length() == 2) rem.add(doubleArrayOf(pair.optDouble(0), pair.optDouble(1)))
                    }
                    all.add(
                        Cand(
                            o.optDouble("start", -1.0), o.optDouble("end", -1.0),
                            o.optString("title", "clip"), o.optString("reason", ""),
                            o.optDouble("score", 5.0), rem
                        )
                    )
                    n++
                }
                okWindows++
                log("Part ${i + 1}/${starts.size}: $n moments mile")
            } catch (e: Exception) {
                log("Part ${i + 1} fail: ${e.message?.take(100)}")
            }
        }
        if (okWindows == 0) throw LlmException("AI se jawab nahi mila. Keys/limit check karo.")
        return refine(all, tr.words, s)
    }

    private fun parseArray(text: String): JSONArray {
        val t = text.trim()
        val a = t.indexOf('[')
        val b = t.lastIndexOf(']')
        if (a >= 0 && b > a) {
            try { return JSONArray(t.substring(a, b + 1)) } catch (_: Exception) {}
        }
        val c = t.indexOf('{')
        val d = t.lastIndexOf('}')
        if (c >= 0 && d > c) {
            val o = JSONObject(t.substring(c, d + 1))
            val keys = o.keys()
            while (keys.hasNext()) {
                val arr = o.optJSONArray(keys.next())
                if (arr != null) return arr
            }
        }
        throw LlmException("AI ka jawab JSON nahi tha")
    }

    private fun refine(raw: List<Cand>, words: List<Word>, s: Settings): List<Cand> {
        if (words.isEmpty()) return emptyList()
        val snapped = ArrayList<Cand>()
        for (c in raw) {
            if (c.start < 0 || c.end <= c.start) continue
            val ws = words.minByOrNull { abs(it.s - c.start) } ?: continue
            val we = words.minByOrNull { abs(it.e - c.end) } ?: continue
            val st = maxOf(ws.s - 0.1, 0.0)
            val en = we.e + 0.2
            val d = en - st
            if (d < s.minSec * 0.6 || d > s.maxSec * 1.35) continue
            snapped.add(c.copy(start = st, end = en))
        }
        snapped.sortByDescending { it.score }
        val keep = ArrayList<Cand>()
        for (c in snapped) {
            if (keep.all { c.end <= it.start || c.start >= it.end }) keep.add(c)
        }
        return keep.take(s.clips).sortedBy { it.start }
    }

    private fun isFiller(w: String) = w.lowercase().trim() in FILLERS

    /** Pause, umm/hmm aur AI ke "remove" hisse kaat ke keep-ranges banata hai. */
    fun buildEditPlan(words: List<Word>, c: Cand, s: Settings): EditPlan {
        val inClip = words.filter { it.s >= c.start - 0.05 && it.e <= c.end + 0.05 }
        fun removed(w: Word) = c.remove.any { w.s >= it[0] - 0.05 && w.e <= it[1] + 0.05 }

        val ranges = ArrayList<Range>()
        if (!s.cutPauses || inClip.isEmpty()) {
            ranges.add(Range(c.start, c.end))
        } else {
            var curStart = -1.0
            var curEnd = -1.0
            var prevIdx = -10
            var prevEnd = 0.0
            for ((idx, w) in inClip.withIndex()) {
                if (isFiller(w.w) || removed(w)) continue
                val split = curStart < 0 || idx - prevIdx > 1 || (w.s - prevEnd) > MAX_KEEP_GAP
                if (split) {
                    if (curStart >= 0) ranges.add(Range(curStart, curEnd))
                    curStart = w.s - 0.05
                }
                curEnd = w.e + 0.10
                prevIdx = idx
                prevEnd = w.e
            }
            if (curStart >= 0) ranges.add(Range(curStart, curEnd))
            // overlap hatao, chhote tukde hatao
            val clean = ArrayList<Range>()
            for (r in ranges) {
                val last = clean.lastOrNull()
                val rs = if (last != null && r.s < last.e) last.e else r.s
                if (r.e - rs >= 0.25) clean.add(Range(rs, r.e))
            }
            ranges.clear()
            ranges.addAll(clean)
            if (ranges.isEmpty()) ranges.add(Range(c.start, c.end))
        }

        // final timeline pe captions
        val caps = ArrayList<CapWord>()
        var off = 0.0
        val bounds = ArrayList<Double>()
        for (r in ranges) {
            for (w in inClip) {
                val mid = (w.s + w.e) / 2
                if (mid < r.s || mid > r.e) continue
                if (s.cutPauses && (isFiller(w.w) || removed(w))) continue
                caps.add(CapWord(w.w, off + (w.s - r.s), off + (w.e - r.s)))
            }
            // zoom boundary: har cut pe, aur lambe hisse me har ~3.4s
            var b = off
            bounds.add(b)
            while (off + r.len - b > ZOOM_STEP * 1.4) {
                b += ZOOM_STEP
                bounds.add(b)
            }
            off += r.len
        }

        val hits = ArrayList<Double>()
        var lastHit = -10.0
        for ((i, b) in bounds.withIndex()) {
            if (i % 2 == 1 && b - lastHit >= 1.4 && b < off - 0.5) {
                hits.add(b); lastHit = b
            }
        }
        return EditPlan(ranges, off, caps, bounds, hits)
    }
}
