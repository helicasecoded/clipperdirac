package com.clipperdirac.app

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil

data class Cand(
    val start: Double,
    val end: Double,
    val title: String,
    val reason: String,
    val score: Double,
    val remove: List<DoubleArray>,
    val headline: String = "",
    val ytTitle: String = "",
    val ytDesc: String = "",
    val igCaption: String = "",
    val hashtags: String = "",
    val hookS: Double = -1.0,
    val hookE: Double = -1.0,
)

data class Range(val s: Double, val e: Double) {
    val len: Double get() = e - s
}

data class CapWord(val w: String, val s: Double, val e: Double)

data class EditPlan(
    val ranges: List<Range>,        // source video ke keep-hisse
    val duration: Double,           // final clip length
    val caps: List<CapWord>,        // captions (final timeline)
    val zoomBounds: List<Double>,   // zoom/cut boundaries (final timeline)
    val hits: List<Double>,         // whoosh timings (final timeline)
)

object ClipPlanner {
    private val FILLERS = setOf(
        "um", "umm", "uh", "uhh", "uhm", "er", "erm", "hmm", "hm", "mm", "mmm", "ah", "ahh", "eh", "huh",
        "हम्म", "हम", "अं", "अम्म", "उम्म", "अह"
    )
    private const val MAX_KEEP_GAP = 0.35   // isse lamba pause kat jayega
    private const val ZOOM_STEP = 3.4

    // ------------------------------------------------------------ prompts
    private val BRIEF_PROMPT = """
You are a senior content strategist and market analyst for short-form video (YouTube Shorts, Instagram Reels, TikTok).
Transcript language: {lang}. Source creator/channel (may be blank): {creator}.
Read this transcript of a {total}s video and write a clipping strategy.

Return ONLY JSON:
{"video_type":"challenge|stream|podcast|vlog|tutorial|other","niche":"short niche description","audience":"who watches and why","premise":"one sentence: what is this video about and what are the stakes","key_beats":["time + what happens (max 8)"],"viral_angles":["what makes a stranger stop scrolling in THIS video (max 6)"],"hook_styles":["hook formats that fit this creator (max 4)"],"avoid":["moments that will flop out of context (max 4)"]}

TRANSCRIPT (seconds):
{transcript}
""".trimIndent()

    private val TREND_PROMPT = """
Use Google Search. Current date: {date}. I make short clips (Shorts / Reels / TikTok) from this kind of video.
Creator/channel: {creator}
Niche: {niche}
Premise: {premise}
Find what is working RIGHT NOW for short clips in this niche or from this creator: popular hook formats, title patterns, hashtags, ideal clip lengths, and what viewers react to most.
Answer in at most 10 short bullet points. No intro, no outro.
""".trimIndent()

    private val PROMPT = """
You are a top short-form video editor and social media growth expert (Reels, YouTube Shorts, TikTok).
The transcript language is {lang}. Think like a market analyst: what would a stranger scrolling at night stop for, watch to the end, and share?

STRATEGY BRIEF FOR THIS VIDEO (may be empty):
{brief}

CURRENT TRENDS (may be empty):
{trends}

This window covers {ws}s to {we}s of a {total}s video. Pick up to {k} BEST moments from this window.

HOOK RULES (most important):
- The first 1-2 seconds decide everything. Open on the most gripping line: a bold claim, a shocking number, a question, a conflict, or the result/reveal.
- Never open with greetings, "so", "um", "welcome back", sponsor talk or slow setup.
- Think MrBeast-style editing: clear stakes, curiosity gap, constant forward momentum, payoff before the viewer gets bored.
- "hook_start"/"hook_end": the single most gripping 2-6 second line INSIDE the clip (exact transcript times). If it is not at the very start, it will be played first as a cold-open teaser.

Every clip MUST:
- Be between {mn} and {mx} seconds long.
- Be self-contained and to the point: setup then payoff. End on a complete thought or punchline, never mid-sentence.
- Skip intros, greetings, sponsor reads, rambling, repeated points, small talk, dead air.
- Include "remove": sub-ranges INSIDE the clip that are useless (restarts, repeated sentences, tangents, thinking aloud). Use exact transcript times. Can be empty.
- Get "score" 1-10 for viral potential. Be strict: scores above 8 are rare.

For every clip also write social text in {outlang}:
- "headline": BIG on-screen hook text, max 8 words, punchy (curiosity or bold claim). Do not just copy the first spoken sentence.
- "yt_title": YouTube Shorts title, max 70 characters, curiosity-driven, honest (no false claims).
- "yt_description": 2-3 short lines about the clip plus a call to action.
- "ig_caption": Instagram caption: strong first-line hook, 1-2 lines of value, call to action (comment / follow / share).
- "hashtags": 5-8 relevant hashtags, each starting with #.

Return ONLY a JSON array, no other text:
[{"start":123.4,"end":170.0,"title":"short internal title","reason":"why it will perform","score":7,"hook_start":150.2,"hook_end":155.0,"remove":[[130.2,133.0]],"headline":"...","yt_title":"...","yt_description":"...","ig_caption":"...","hashtags":["#tag1","#tag2"]}]

TRANSCRIPT (seconds):
{transcript}
""".trimIndent()

    private val RANK_PROMPT = """
You are the editor-in-chief of a short-form channel. Below are candidate clips cut from ONE long video.
Video premise: {premise}
Pick the best {n} clips to publish, ordered best first.
Judge by: strongest opening hook, stakes / curiosity, emotional or surprising payoff, standalone clarity.
Avoid near-duplicate topics; prefer variety. Reject weak or context-dependent clips.

Return ONLY JSON like {"picks":[3,0,7]} using the candidate numbers.

CANDIDATES:
{list}
""".trimIndent()

    // ------------------------------------------------------------- planning
    private fun condense(tr: TranscriptResult, maxChars: Int): String {
        val lines = tr.segs.map { String.format(Locale.US, "[%d] %s", it.s.toInt(), it.t.take(160)) }
        val total = lines.sumOf { it.length + 1 }
        if (total <= maxChars) return lines.joinToString("\n")
        val step = ceil(total.toDouble() / maxChars).toInt().coerceAtLeast(2)
        return lines.filterIndexed { i, _ -> i % step == 0 }.joinToString("\n")
    }

    private fun parseObject(text: String): JSONObject {
        val t = text.trim()
        val a = t.indexOf('{')
        val b = t.lastIndexOf('}')
        if (a >= 0 && b > a) return JSONObject(t.substring(a, b + 1))
        throw LlmException("AI ka jawab JSON nahi tha")
    }

    fun plan(
        tr: TranscriptResult,
        s: Settings,
        router: LlmRouter,
        log: (String) -> Unit,
        stage: (String, Float) -> Unit,
    ): List<Cand> {
        val total = tr.segs.maxOf { it.e }
        val langName = Transcriber.langLabel(s.language)
        val creator = s.creator.trim().ifBlank { "unknown" }

        var brief = ""
        var trends = ""
        var premise = ""
        var niche = ""
        if (s.analyst) {
            stage("Analyst poori video samajh raha hai...", 0.0f)
            try {
                val prompt = BRIEF_PROMPT
                    .replace("{lang}", langName).replace("{creator}", creator)
                    .replace("{total}", total.toInt().toString())
                    .replace("{transcript}", condense(tr, 90_000))
                val j = parseObject(router.generateJson(prompt))
                brief = j.toString().take(3500)
                premise = j.optString("premise")
                niche = j.optString("niche")
                log("Video type: ${j.optString("video_type")} | $niche")
            } catch (e: Exception) {
                log("Analyst step skip: ${e.message?.take(80)}")
            }
            stage("Market trends check ho rahe hain...", 0.12f)
            val tp = TREND_PROMPT
                .replace("{date}", SimpleDateFormat("d MMMM yyyy", Locale.US).format(Date()))
                .replace("{creator}", creator)
                .replace("{niche}", niche.ifBlank { "unknown" })
                .replace("{premise}", premise.ifBlank { "unknown" })
            trends = router.searchText(tp).take(2500)
            log(if (trends.isBlank()) "Live trends nahi mile, AI apna knowledge use karega" else "Live trends mil gaye")
        }

        val winLen = 720.0
        val overlap = 45.0
        val starts = ArrayList<Double>()
        var t = 0.0
        do {
            starts.add(t)
            t += winLen - overlap
        } while (t < total - 60.0)
        val k = ceil(s.clips * 3.0 / starts.size).toInt().coerceIn(3, 8)

        val all = ArrayList<Cand>()
        var okWindows = 0
        for ((i, ws) in starts.withIndex()) {
            val we = ws + winLen
            val lines = tr.segs.filter { it.e > ws && it.s < we }
                .joinToString("\n") { String.format(Locale.US, "[%.1f-%.1f] %s", it.s, it.e, it.t) }
            if (lines.isBlank()) continue
            stage("AI best moments dhundh raha hai (${i + 1}/${starts.size})...", 0.2f + 0.65f * i / starts.size)
            val prompt = PROMPT
                .replace("{lang}", langName)
                .replace("{outlang}", if (s.outLang == "en") "English" else "the same language as the transcript")
                .replace("{brief}", brief.ifBlank { "(none)" })
                .replace("{trends}", trends.ifBlank { "(none)" })
                .replace("{ws}", ws.toInt().toString())
                .replace("{we}", minOf(we, total).toInt().toString())
                .replace("{total}", total.toInt().toString())
                .replace("{k}", k.toString())
                .replace("{mn}", s.minSec.toString())
                .replace("{mx}", s.maxSec.toString())
                .replace("{transcript}", lines)
            try {
                val arr = parseArray(router.generateJson(prompt))
                var n = 0
                for (j in 0 until arr.length()) {
                    val o = arr.optJSONObject(j) ?: continue
                    val rem = ArrayList<DoubleArray>()
                    val ra = o.optJSONArray("remove")
                    if (ra != null) for (r in 0 until ra.length()) {
                        val pair = ra.optJSONArray(r) ?: continue
                        if (pair.length() == 2) rem.add(doubleArrayOf(pair.optDouble(0), pair.optDouble(1)))
                    }
                    val tags = StringBuilder()
                    val ha = o.optJSONArray("hashtags")
                    if (ha != null) for (h in 0 until ha.length()) {
                        var tg = ha.optString(h).trim().replace(" ", "")
                        if (tg.isNotEmpty()) {
                            if (!tg.startsWith("#")) tg = "#$tg"
                            tags.append(tg).append(' ')
                        }
                    }
                    all.add(
                        Cand(
                            start = o.optDouble("start", -1.0), end = o.optDouble("end", -1.0),
                            title = o.optString("title", "clip"), reason = o.optString("reason", ""),
                            score = o.optDouble("score", 5.0), remove = rem,
                            headline = o.optString("headline", ""),
                            ytTitle = o.optString("yt_title", ""),
                            ytDesc = o.optString("yt_description", ""),
                            igCaption = o.optString("ig_caption", ""),
                            hashtags = tags.toString().trim(),
                            hookS = o.optDouble("hook_start", -1.0),
                            hookE = o.optDouble("hook_end", -1.0),
                        )
                    )
                    n++
                }
                okWindows++
                log("Part ${i + 1}/${starts.size}: $n moments mile")
            } catch (e: Exception) {
                log("Part ${i + 1} fail: ${e.message?.take(100)}")
            }
        }
        if (okWindows == 0) throw LlmException("AI se jawab nahi mila. Keys/limit check karo.")

        val pool = refine(all, tr.words, s, 40)
        val finalList = if (s.analyst && pool.size > s.clips) {
            stage("Editor-in-chief final clips chun raha hai...", 0.9f)
            rank(pool, tr.words, s, premise, router, log)
        } else pool.sortedByDescending { it.score }.take(s.clips)
        return finalList.sortedBy { it.start }
    }

    private fun rank(
        pool: List<Cand>, words: List<Word>, s: Settings, premise: String,
        router: LlmRouter, log: (String) -> Unit,
    ): List<Cand> {
        val sb = StringBuilder()
        for ((i, c) in pool.withIndex()) {
            val opening = words.filter { it.s >= c.start && it.s < c.start + 8 }.joinToString(" ") { it.w }
            sb.append(
                String.format(
                    Locale.US, "#%d [%d-%d | %ds | score %.0f] %s | %s | opening: \"%s\"\n",
                    i, c.start.toInt(), c.end.toInt(), (c.end - c.start).toInt(), c.score,
                    c.headline.ifBlank { c.title }, c.reason.take(120), opening
                )
            )
        }
        try {
            val prompt = RANK_PROMPT
                .replace("{premise}", premise.ifBlank { "unknown" })
                .replace("{n}", s.clips.toString())
                .replace("{list}", sb.toString())
            val arr = parseObject(router.generateJson(prompt)).optJSONArray("picks")
            val picks = ArrayList<Int>()
            if (arr != null) for (i in 0 until arr.length()) {
                val idx = arr.optInt(i, -1)
                if (idx in pool.indices && idx !in picks) picks.add(idx)
            }
            if (picks.isNotEmpty()) {
                val chosen = picks.map { pool[it] }.toMutableList()
                for (c in pool.sortedByDescending { it.score }) {
                    if (chosen.size >= s.clips) break
                    if (c !in chosen) chosen.add(c)
                }
                log("Final ranking: ${chosen.size.coerceAtMost(s.clips)} clips chune")
                return chosen.take(s.clips)
            }
        } catch (e: Exception) {
            log("Ranking skip: ${e.message?.take(80)}")
        }
        return pool.sortedByDescending { it.score }.take(s.clips)
    }

    private fun parseArray(text: String): JSONArray {
        val t = text.trim()
        val a = t.indexOf('[')
        val b = t.lastIndexOf(']')
        if (a >= 0 && b > a) {
            try { return JSONArray(t.substring(a, b + 1)) } catch (_: Exception) {}
        }
        val c = t.indexOf('{')
        val d = t.lastIndexOf('}')
        if (c >= 0 && d > c) {
            val o = JSONObject(t.substring(c, d + 1))
            val keys = o.keys()
            while (keys.hasNext()) {
                val arr = o.optJSONArray(keys.next())
                if (arr != null) return arr
            }
        }
        throw LlmException("AI ka jawab JSON nahi tha")
    }

    private fun refine(raw: List<Cand>, words: List<Word>, s: Settings, limit: Int): List<Cand> {
        if (words.isEmpty()) return emptyList()
        val snapped = ArrayList<Cand>()
        for (c in raw) {
            if (c.start < 0 || c.end <= c.start) continue
            val ws = words.minByOrNull { abs(it.s - c.start) } ?: continue
            val we = words.minByOrNull { abs(it.e - c.end) } ?: continue
            val st = maxOf(ws.s - 0.1, 0.0)
            val en = we.e + 0.2
            val d = en - st
            if (d < s.minSec * 0.6 || d > s.maxSec * 1.35) continue
            snapped.add(c.copy(start = st, end = en))
        }
        snapped.sortByDescending { it.score }
        val keep = ArrayList<Cand>()
        for (c in snapped) {
            if (keep.all { c.end <= it.start || c.start >= it.end }) keep.add(c)
        }
        return keep.take(limit)
    }

    private fun isFiller(w: String) = w.lowercase().trim() in FILLERS

    /** Pause, umm/hmm, AI ke "remove" hisse kaat ke keep-ranges banata hai; hook ho to cold-open lagata hai. */
    fun buildEditPlan(words: List<Word>, c: Cand, s: Settings): EditPlan {
        val inClip = words.filter { it.s >= c.start - 0.05 && it.e <= c.end + 0.05 }
        fun removed(w: Word) = c.remove.any { w.s >= it[0] - 0.05 && w.e <= it[1] + 0.05 }

        val ranges = ArrayList<Range>()
        if (!s.cutPauses || inClip.isEmpty()) {
            ranges.add(Range(c.start, c.end))
        } else {
            var curStart = -1.0
            var curEnd = -1.0
            var prevIdx = -10
            var prevEnd = 0.0
            for ((idx, w) in inClip.withIndex()) {
                if (isFiller(w.w) || removed(w)) continue
                val split = curStart < 0 || idx - prevIdx > 1 || (w.s - prevEnd) > MAX_KEEP_GAP
                if (split) {
                    if (curStart >= 0) ranges.add(Range(curStart, curEnd))
                    curStart = w.s - 0.05
                }
                curEnd = w.e + 0.10
                prevIdx = idx
                prevEnd = w.e
            }
            if (curStart >= 0) ranges.add(Range(curStart, curEnd))
            val clean = ArrayList<Range>()
            for (r in ranges) {
                val last = clean.lastOrNull()
                val rs = if (last != null && r.s < last.e) last.e else r.s
                if (r.e - rs >= 0.25) clean.add(Range(rs, r.e))
            }
            ranges.clear()
            ranges.addAll(clean)
            if (ranges.isEmpty()) ranges.add(Range(c.start, c.end))
        }

        // Cold open: sabse gripping line pehle, phir poori clip
        if (s.coldOpen && inClip.isNotEmpty() && c.hookS >= c.start && c.hookE <= c.end &&
            c.hookE - c.hookS in 1.5..8.0 && c.hookS - c.start > 6.0
        ) {
            val hs = inClip.minByOrNull { abs(it.s - c.hookS) }
            val he = inClip.minByOrNull { abs(it.e - c.hookE) }
            if (hs != null && he != null && he.e > hs.s) ranges.add(0, Range(hs.s - 0.05, he.e + 0.10))
        }

        val caps = ArrayList<CapWord>()
        var off = 0.0
        val bounds = ArrayList<Double>()
        for (r in ranges) {
            for (w in inClip) {
                val mid = (w.s + w.e) / 2
                if (mid < r.s || mid > r.e) continue
                if (s.cutPauses && (isFiller(w.w) || removed(w))) continue
                caps.add(CapWord(w.w, off + (w.s - r.s), off + (w.e - r.s)))
            }
            var b = off
            bounds.add(b)
            while (off + r.len - b > ZOOM_STEP * 1.4) {
                b += ZOOM_STEP
                bounds.add(b)
            }
            off += r.len
        }

        val hits = ArrayList<Double>()
        var lastHit = -10.0
        for ((i, b) in bounds.withIndex()) {
            if (i % 2 == 1 && b - lastHit >= 1.4 && b < off - 0.5) {
                hits.add(b); lastHit = b
            }
        }
        return EditPlan(ranges, off, caps, bounds, hits)
    }
}
