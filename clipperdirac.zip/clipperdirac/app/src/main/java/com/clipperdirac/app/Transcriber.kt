package com.clipperdirac.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.URL
import java.nio.ByteOrder
import java.util.zip.ZipInputStream

data class Word(val w: String, val s: Double, val e: Double)
data class Seg(val s: Double, val e: Double, val t: String)
class TranscriptResult(val words: List<Word>, val segs: List<Seg>)

/** Video ka audio -> 16kHz mono PCM16, chunk-by-chunk. */
object AudioDecoder {
    fun decode(
        ctx: Context,
        uri: Uri,
        onChunk: (ByteArray, Int) -> Unit,
        onProgress: (Double) -> Unit,
        isCancelled: () -> Boolean,
    ) {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var track = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                track = i; fmt = f; break
            }
        }
        if (track < 0 || fmt == null) {
            ex.release()
            throw IllegalStateException("Is video me audio track nahi mila")
        }
        ex.selectTrack(track)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        val durationUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
        var inRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var inCh = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()

        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var phase = 0.0
        var prevLast = 0f
        val outBuf = ByteArray(32_000)
        var outLen = 0
        var lastProgress = 0.0

        try {
            while (!outputDone) {
                if (isCancelled()) break
                if (!inputDone) {
                    val idx = codec.dequeueInputBuffer(5_000)
                    if (idx >= 0) {
                        val buf = codec.getInputBuffer(idx)!!
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val t = ex.sampleTime
                            codec.queueInputBuffer(idx, 0, size, t, 0)
                            if (durationUs > 0 && t - lastProgress * durationUs > durationUs * 0.01) {
                                lastProgress = t.toDouble() / durationUs
                                onProgress(lastProgress.coerceIn(0.0, 1.0))
                            }
                            ex.advance()
                        }
                    }
                }
                val out = codec.dequeueOutputBuffer(info, 5_000)
                if (out >= 0) {
                    val ob = codec.getOutputBuffer(out)!!
                    if (info.size > 0) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val frames = sb.remaining() / inCh
                        val mono = FloatArray(frames)
                        for (f in 0 until frames) {
                            var sum = 0f
                            for (c in 0 until inCh) sum += sb.get()
                            mono[f] = sum / inCh
                        }
                        val step = inRate / 16000.0
                        while (phase < frames - 1) {
                            val i0 = Math.floor(phase).toInt()
                            val frac = (phase - i0).toFloat()
                            val s0 = if (i0 < 0) prevLast else mono[i0]
                            val s1 = mono[i0 + 1]
                            val v = (s0 + (s1 - s0) * frac).toInt().coerceIn(-32768, 32767)
                            outBuf[outLen++] = (v and 0xFF).toByte()
                            outBuf[outLen++] = ((v shr 8) and 0xFF).toByte()
                            if (outLen >= outBuf.size - 1) {
                                onChunk(outBuf, outLen); outLen = 0
                            }
                            phase += step
                        }
                        phase -= frames
                        if (frames > 0) prevLast = mono[frames - 1]
                    }
                    codec.releaseOutputBuffer(out, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                } else if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    inRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    inCh = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            if (outLen > 0) onChunk(outBuf, outLen)
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            ex.release()
        }
    }
}

object Transcriber {
    private fun modelName(lang: String) =
        if (lang == "hi") "vosk-model-small-hi-0.22" else "vosk-model-small-en-us-0.15"

    /** Speech model pehli baar download hota hai (~40MB), phir offline chalta hai. */
    fun ensureModel(ctx: Context, lang: String, onProgress: (Double) -> Unit): File {
        val root = File(ctx.filesDir, "vosk").apply { mkdirs() }
        val name = modelName(lang)
        val dir = File(root, name)
        if (File(dir, "am").exists() && File(dir, "conf").exists()) return dir

        val zip = File(root, "$name.zip")
        val conn = URL("https://alphacephei.com/vosk/models/$name.zip").openConnection()
        conn.connectTimeout = 20_000
        conn.readTimeout = 60_000
        val total = conn.contentLengthLong
        conn.getInputStream().use { input ->
            zip.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) onProgress(done.toDouble() / total)
                }
            }
        }
        dir.deleteRecursively()
        val rootCanon = root.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val f = File(root, e.name)
                if (!f.canonicalPath.startsWith(rootCanon)) continue
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    f.outputStream().use { zin.copyTo(it) }
                }
            }
        }
        zip.delete()
        return dir
    }

    fun transcribe(
        ctx: Context,
        uri: Uri,
        modelDir: File,
        onProgress: (Double) -> Unit,
        isCancelled: () -> Boolean,
    ): TranscriptResult {
        LibVosk.setLogLevel(LogLevel.WARNINGS)
        val words = ArrayList<Word>()
        val segs = ArrayList<Seg>()

        fun handle(json: String) {
            val arr = JSONObject(json).optJSONArray("result") ?: return
            if (arr.length() == 0) return
            val ws = ArrayList<Word>()
            for (i in 0 until arr.length()) {
                val w = arr.getJSONObject(i)
                ws.add(Word(w.getString("word"), w.getDouble("start"), w.getDouble("end")))
            }
            words.addAll(ws)
            segs.add(Seg(ws.first().s, ws.last().e, ws.joinToString(" ") { it.w }))
        }

        val model = Model(modelDir.absolutePath)
        val rec = Recognizer(model, 16000f)
        try {
            rec.setWords(true)
            AudioDecoder.decode(
                ctx, uri,
                { buf, len -> if (rec.acceptWaveForm(buf, len)) handle(rec.result) },
                onProgress, isCancelled
            )
            handle(rec.finalResult)
        } finally {
            rec.close()
            model.close()
        }
        return TranscriptResult(words, segs)
    }
}
