package com.clipperdirac.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PointF
import android.media.FaceDetector
import android.media.MediaMetadataRetriever
import android.net.Uri

/**
 * Speaker ke face ka track (source video ke time pe).
 * nx, ny: poore frame ke NDC coordinates (-1..1, y upar +).
 * baseZoom: face chhota ho to extra zoom (1.0 = zaroorat nahi). cw: 9:16 crop ki chaudai (frame ka fraction).
 */
class FaceTrack(
    val t: DoubleArray,
    val nx: FloatArray,
    val ny: FloatArray,
    val baseZoom: Float,
    val cw: Float,
) {
    fun at(time: Double): FloatArray {
        if (t.isEmpty()) return floatArrayOf(0f, 0f)
        if (time <= t[0]) return floatArrayOf(nx[0], ny[0])
        for (i in 1 until t.size) {
            if (time <= t[i]) {
                val f = ((time - t[i - 1]) / (t[i] - t[i - 1])).toFloat()
                return floatArrayOf(nx[i - 1] + (nx[i] - nx[i - 1]) * f, ny[i - 1] + (ny[i] - ny[i - 1]) * f)
            }
        }
        return floatArrayOf(nx.last(), ny.last())
    }
}

object FaceAnalyzer {
    private fun smooth(a: FloatArray): FloatArray {
        val o = a.copyOf()
        for (i in a.indices) {
            val p = a[maxOf(i - 1, 0)]
            val q = a[minOf(i + 1, a.size - 1)]
            o[i] = (p + a[i] + q) / 3f
        }
        return o
    }

    /** Clip ke har 1 second pe frame lekar face dhundta hai. Face kam mile to null (center crop hi rahega). */
    fun analyze(ctx: Context, uri: Uri, startS: Double, endS: Double): FaceTrack? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val w0 = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: return null
            val h0 = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: return null
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val w = if (rot == 90 || rot == 270) h0 else w0
            val h = if (rot == 90 || rot == 270) w0 else h0
            val cw = minOf(1f, 9f / 16f * h / w)
            val dw = 320
            val dh = (dw.toFloat() * h / w).toInt().coerceAtLeast(64)

            val times = ArrayList<Double>()
            var tt = startS
            while (tt < endS) { times.add(tt); tt += 1.0 }
            if (times.size < 3) return null
            val n = times.size
            val xs = FloatArray(n) { Float.NaN }
            val ys = FloatArray(n) { Float.NaN }
            val fw = FloatArray(n) { Float.NaN }
            val det = FaceDetector(dw, dh, 3)
            var found = 0

            for (i in 0 until n) {
                val raw = r.getScaledFrameAtTime(
                    (times[i] * 1_000_000).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC, dw, dh
                ) ?: continue
                val bmp = Bitmap.createScaledBitmap(raw, dw, dh, true).copy(Bitmap.Config.RGB_565, false) ?: continue
                val faces = arrayOfNulls<FaceDetector.Face>(3)
                val cnt = det.findFaces(bmp, faces)
                var best = 0f
                for (k in 0 until cnt) {
                    val f = faces[k] ?: continue
                    if (f.confidence() < 0.4f) continue
                    val ed = f.eyesDistance()
                    if (ed > best) {
                        best = ed
                        val p = PointF()
                        f.getMidPoint(p)
                        xs[i] = p.x / dw * 2f - 1f
                        ys[i] = 1f - (p.y + 0.35f * ed) / dh * 2f
                        fw[i] = ed * 2.2f / dw
                    }
                }
                if (best > 0f) found++
            }
            if (found < n * 0.35) return null

            // gaps bharo (aage se, phir peeche se)
            var lx = Float.NaN; var ly = Float.NaN; var lw = Float.NaN
            for (i in 0 until n) {
                if (xs[i].isNaN()) {
                    if (!lx.isNaN()) { xs[i] = lx; ys[i] = ly; fw[i] = lw }
                } else { lx = xs[i]; ly = ys[i]; lw = fw[i] }
            }
            for (i in n - 1 downTo 0) {
                if (xs[i].isNaN()) { xs[i] = lx; ys[i] = ly; fw[i] = lw } else { lx = xs[i]; ly = ys[i]; lw = fw[i] }
            }
            val sx = smooth(smooth(xs))
            val sy = smooth(smooth(ys))

            val sorted = fw.filter { !it.isNaN() }.sorted()
            val median = if (sorted.isEmpty()) 0.2f else sorted[sorted.size / 2]
            val faceFrac = median / cw
            val zoom = if (faceFrac <= 0f) 1f else (0.38f / faceFrac).coerceIn(1f, 1.5f)

            return FaceTrack(times.toDoubleArray(), sx, sy, zoom, cw)
        } catch (e: Exception) {
            return null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }
}
