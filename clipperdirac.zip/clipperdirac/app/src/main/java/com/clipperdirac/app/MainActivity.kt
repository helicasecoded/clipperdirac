package com.clipperdirac.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) { Screen(vm) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Screen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val s = vm.settings

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            vm.pickVideo(uri)
        }
    }
    val pickMusic = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            vm.update(s.copy(musicUri = uri.toString()))
        }
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🎬 Clipperdirac", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Lambi video se viral clips: auto cut, zoom, captions, SFX", fontSize = 13.sp)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("API Keys (kam se kam ek)", fontWeight = FontWeight.SemiBold)
                KeyField("Gemini key 1", s.gemini1) { vm.update(s.copy(gemini1 = it)) }
                KeyField("Gemini key 2", s.gemini2) { vm.update(s.copy(gemini2 = it)) }
                KeyField("Grok (xAI) key", s.grok) { vm.update(s.copy(grok = it)) }
                Text("Keys sirf aapke phone me save hoti hain. Sab keys baari-baari use hongi; limit lage to agli.", fontSize = 12.sp)
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Video", fontWeight = FontWeight.SemiBold)
                Button(onClick = { pickVideo.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (vm.videoUri == null) "Video chuno" else "Video badlo")
                }
                if (vm.videoUri != null) Text(vm.videoName, fontSize = 13.sp)

                Text("Bolne ki language")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(s.language == "en", { vm.update(s.copy(language = "en")) }, { Text("English") })
                    FilterChip(s.language == "hi", { vm.update(s.copy(language = "hi")) }, { Text("Hindi") })
                }

                Text("Clip length")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15 to 30, 30 to 60, 60 to 90).forEach { (a, b) ->
                        FilterChip(
                            s.minSec == a && s.maxSec == b,
                            { vm.update(s.copy(minSec = a, maxSec = b)) },
                            { Text("$a-${b}s") }
                        )
                    }
                }

                Text("Kitni clips: ${s.clips}")
                Slider(
                    value = s.clips.toFloat(),
                    onValueChange = { vm.update(s.copy(clips = it.toInt())) },
                    valueRange = 1f..10f, steps = 8
                )
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Editing", fontWeight = FontWeight.SemiBold)
                SwitchRow("Pause, umm, hmm kaato", s.cutPauses) { vm.update(s.copy(cutPauses = it)) }
                SwitchRow("Auto zoom (cut pe punch-in)", s.zoom) { vm.update(s.copy(zoom = it)) }
                SwitchRow("Bade captions", s.captions) { vm.update(s.copy(captions = it)) }
                SwitchRow("Whoosh sound effects", s.sfx) { vm.update(s.copy(sfx = it)) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { pickMusic.launch(arrayOf("audio/*")) }) {
                        Text(if (s.musicUri.isBlank()) "Background music" else "Music badlo")
                    }
                    if (s.musicUri.isNotBlank()) TextButton(onClick = { vm.update(s.copy(musicUri = "")) }) { Text("Hatao") }
                }
                if (s.musicUri.isNotBlank()) {
                    Text("Music volume", fontSize = 12.sp)
                    Slider(
                        value = s.musicVol,
                        onValueChange = { vm.update(s.copy(musicVol = it)) },
                        valueRange = 0.03f..0.4f
                    )
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { vm.start() },
                enabled = !vm.running,
                modifier = Modifier.weight(1f)
            ) { Text("🚀 Clips banao") }
            if (vm.running) OutlinedButton(onClick = { vm.stop() }) { Text("Stop") }
        }

        if (vm.status.isNotBlank()) {
            Text(vm.status, fontWeight = FontWeight.Medium)
            if (vm.running) LinearProgressIndicator(progress = { vm.progress }, modifier = Modifier.fillMaxWidth())
        }
        vm.logLines.forEach { Text(it, fontSize = 11.sp) }

        if (vm.projects.isNotEmpty()) {
            HorizontalDivider()
            Text("📂 Aapki clips", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Gallery > Movies > Clipperdirac folder me bhi mil jayengi", fontSize = 12.sp)
        }
        vm.projects.forEach { p ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(p.folder, fontWeight = FontWeight.SemiBold)
                    p.clips.forEachIndexed { i, c ->
                        Column(Modifier.padding(top = 8.dp)) {
                            Text("${i + 1}. ${c.title}  (${c.dur.toInt()}s)")
                            if (c.reason.isNotBlank()) Text(c.reason, fontSize = 11.sp)
                            Row {
                                TextButton(onClick = { openClip(ctx, c.uri) }) { Text("▶ Play") }
                                TextButton(onClick = { shareClip(ctx, c.uri) }) { Text("Share") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KeyField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        singleLine = true, visualTransformation = PasswordVisualTransformation(),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun openClip(ctx: android.content.Context, uri: String) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), "video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    } catch (_: Exception) {}
}

private fun shareClip(ctx: android.content.Context, uri: String) {
    try {
        val i = Intent(Intent.ACTION_SEND).setType("video/mp4")
            .putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share clip"))
    } catch (_: Exception) {}
}
