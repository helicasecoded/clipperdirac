package com.clipperdirac.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) { Screen(vm) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun Screen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val s = vm.settings
    var advanced by remember { mutableStateOf(false) }

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            vm.pickVideo(uri)
        }
    }
    val pickMusic = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            vm.update(s.copy(musicUri = uri.toString()))
        }
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🎬 Clipperdirac", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Lambi video se viral clips + title, description, caption", fontSize = 13.sp)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("API Keys (jitni chahe)", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(
                    value = s.keys,
                    onValueChange = { vm.update(s.copy(keys = it)) },
                    label = { Text("Ek line me ek key paste karo") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(KeyParser.summary(s.keys), fontSize = 12.sp)
                Text(
                    "\"xai-\" se shuru = Grok, baaki sab Gemini. Keys sirf aapke phone me save hoti hain. " +
                        "Baari-baari use hoti hain; limit lage to agli key.",
                    fontSize = 11.sp
                )
                TextButton(onClick = { advanced = !advanced }) {
                    Text(if (advanced) "Advanced chhupao" else "Advanced (model ka naam)")
                }
                if (advanced) {
                    OutlinedTextField(
                        value = s.geminiModel, onValueChange = { vm.update(s.copy(geminiModel = it)) },
                        label = { Text("Gemini model (khali = gemini-flash-latest)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = s.grokModel, onValueChange = { vm.update(s.copy(grokModel = it)) },
                        label = { Text("Grok model (khali = auto, newest fast)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Video", fontWeight = FontWeight.SemiBold)
                Button(onClick = { pickVideo.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (vm.videoUri == null) "Video chuno" else "Video badlo")
                }
                if (vm.videoUri != null) Text(vm.videoName, fontSize = 13.sp)

                OutlinedTextField(
                    value = s.creator, onValueChange = { vm.update(s.copy(creator = it)) },
                    label = { Text("Source creator / channel (jaise MrBeast)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Text("Video me bolne ki language (har video ke liye sahi chuno)")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Transcriber.LANGS.forEach { (code, label) ->
                        FilterChip(s.language == code, { vm.update(s.copy(language = code)) }, { Text(label) })
                    }
                }

                Text("Title / description / caption kis language me")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(s.outLang == "same", { vm.update(s.copy(outLang = "same")) }, { Text("Video wali") })
                    FilterChip(s.outLang == "en", { vm.update(s.copy(outLang = "en")) }, { Text("English") })
                }

                Text("Clip length")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15 to 30, 30 to 60, 60 to 90).forEach { (a, b) ->
                        FilterChip(
                            s.minSec == a && s.maxSec == b,
                            { vm.update(s.copy(minSec = a, maxSec = b)) },
                            { Text("$a-${b}s") }
                        )
                    }
                }

                Text("Kitni clips: ${s.clips}")
                Slider(
                    value = s.clips.toFloat(),
                    onValueChange = { vm.update(s.copy(clips = it.toInt())) },
                    valueRange = 1f..10f, steps = 8
                )
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Editing", fontWeight = FontWeight.SemiBold)
                SwitchRow("Smart analyst + trend research", s.analyst) { vm.update(s.copy(analyst = it)) }
                SwitchRow("Sabse gripping line pehle (cold open)", s.coldOpen) { vm.update(s.copy(coldOpen = it)) }
                SwitchRow("Pause, umm, hmm kaato", s.cutPauses) { vm.update(s.copy(cutPauses = it)) }
                SwitchRow("Auto zoom (cut pe punch-in)", s.zoom) { vm.update(s.copy(zoom = it)) }
                SwitchRow("Bade captions (word-by-word)", s.captions) { vm.update(s.copy(captions = it)) }
                SwitchRow("Upar bada headline text", s.headline) { vm.update(s.copy(headline = it)) }
                SwitchRow("Whoosh sound effects", s.sfx) { vm.update(s.copy(sfx = it)) }
                OutlinedTextField(
                    value = s.handle, onValueChange = { vm.update(s.copy(handle = it)) },
                    label = { Text("Apna handle (video pe neeche likha aayega)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { pickMusic.launch(arrayOf("audio/*")) }) {
                        Text(if (s.musicUri.isBlank()) "Background music" else "Music badlo")
                    }
                    if (s.musicUri.isNotBlank()) TextButton(onClick = { vm.update(s.copy(musicUri = "")) }) { Text("Hatao") }
                }
                if (s.musicUri.isNotBlank()) {
                    Text("Music volume", fontSize = 12.sp)
                    Slider(
                        value = s.musicVol,
                        onValueChange = { vm.update(s.copy(musicVol = it)) },
                        valueRange = 0.03f..0.4f
                    )
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { vm.start() },
                enabled = !vm.running,
                modifier = Modifier.weight(1f)
            ) { Text("🚀 Clips banao") }
            if (vm.running) OutlinedButton(onClick = { vm.stop() }) { Text("Stop") }
        }

        if (vm.status.isNotBlank()) {
            Text(vm.status, fontWeight = FontWeight.Medium)
            if (vm.running) LinearProgressIndicator(progress = { vm.progress }, modifier = Modifier.fillMaxWidth())
        }
        vm.logLines.forEach { Text(it, fontSize = 11.sp) }

        if (vm.projects.isNotEmpty()) {
            HorizontalDivider()
            Text("📂 Aapki clips", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Gallery > Movies > Clipperdirac folder me bhi mil jayengi", fontSize = 12.sp)
        }
        vm.projects.forEach { p ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(p.folder, fontWeight = FontWeight.SemiBold)
                    p.clips.forEachIndexed { i, c ->
                        Column(Modifier.padding(top = 10.dp)) {
                            Text("${i + 1}. ${c.title}  (${c.dur.toInt()}s)", fontWeight = FontWeight.Medium)
                            if (c.ytTitle.isNotBlank()) Text("YT: ${c.ytTitle}", fontSize = 12.sp)
                            if (c.reason.isNotBlank()) Text(c.reason, fontSize = 11.sp)
                            FlowRow {
                                TextButton(onClick = { openClip(ctx, c.uri) }) { Text("▶ Play") }
                                TextButton(onClick = { shareClip(ctx, c.uri) }) { Text("Share") }
                                if (c.ytTitle.isNotBlank()) TextButton(onClick = {
                                    copyText(ctx, listOf(c.ytTitle, c.ytDesc, c.hashtags).filter { it.isNotBlank() }.joinToString("\n\n"))
                                }) { Text("Copy YT") }
                                if (c.igCaption.isNotBlank()) TextButton(onClick = {
                                    copyText(ctx, listOf(c.igCaption, c.hashtags).filter { it.isNotBlank() }.joinToString("\n\n"))
                                }) { Text("Copy IG") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("clipperdirac", text))
    Toast.makeText(ctx, "Copy ho gaya", Toast.LENGTH_SHORT).show()
}

private fun openClip(ctx: Context, uri: String) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), "video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    } catch (_: Exception) {}
}

private fun shareClip(ctx: Context, uri: String) {
    try {
        val i = Intent(Intent.ACTION_SEND).setType("video/mp4")
            .putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share clip"))
    } catch (_: Exception) {}
}
