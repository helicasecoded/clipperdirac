package com.clipperdirac.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Size
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

// ------------------------------------------------------------------ theme
private val Bg = Color(0xFF0D0F14)
private val SurfaceC = Color(0xFF141821)
private val CardC = Color(0xFF1A1F2B)
private val OutlineC = Color(0xFF2A3140)
private val Primary = Color(0xFF7C5CFF)
private val Accent = Color(0xFF00D1B2)
private val Muted = Color(0xFF9AA3B5)

@Composable
fun ProTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Primary, onPrimary = Color.White,
            secondary = Accent, onSecondary = Color.Black,
            secondaryContainer = Color(0xFF2B2358), onSecondaryContainer = Color.White,
            background = Bg, surface = SurfaceC, surfaceVariant = CardC,
            onSurface = Color(0xFFEDEFF5), onSurfaceVariant = Muted,
            outline = OutlineC,
        ),
        content = content
    )
}

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) { App(vm) }
            }
        }
    }
}

@Composable
fun App(vm: AppViewModel) {
    var tab by remember { mutableStateOf(0) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = SurfaceC) {
                listOf("🎬" to "Create", "📚" to "Library", "💰" to "Campaigns", "⚙️" to "Settings")
                    .forEachIndexed { i, (emoji, label) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(emoji, fontSize = 20.sp) },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> CreateScreen(vm)
                1 -> LibraryScreen(vm)
                2 -> CampaignsScreen(vm)
                else -> SettingsScreen(vm)
            }
        }
    }
}

// ---------------------------------------------------------------- helpers
@Composable
fun ProCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardC),
        border = BorderStroke(1.dp, OutlineC)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Accent)
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun ScoreBadge(score: Double) {
    val col = when {
        score >= 8 -> Color(0xFF1DB954)
        score >= 6 -> Color(0xFFFFB020)
        else -> Color(0xFF8A93A5)
    }
    Box(Modifier.background(col.copy(alpha = 0.18f), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 3.dp)) {
        Text("🔥 ${String.format(Locale.US, "%.0f", score)}/10", color = col, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

fun fmtTime(t: Double): String {
    val m = (t / 60).toInt()
    val sec = t - m * 60
    return String.format(Locale.US, "%d:%04.1f", m, sec)
}

private fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("clipperdirac", text))
    Toast.makeText(ctx, "Copy ho gaya", Toast.LENGTH_SHORT).show()
}

private fun shareClip(ctx: Context, uri: String) {
    try {
        val i = Intent(Intent.ACTION_SEND).setType("video/mp4")
            .putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share clip"))
    } catch (_: Exception) {}
}

private fun persist(ctx: Context, uri: Uri) {
    try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
}

// ----------------------------------------------------------------- create
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val s = vm.settings
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { persist(ctx, it) }
        vm.addVideos(uris)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            Modifier.fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(Color(0xFF5B3DF5), Color(0xFF00B8A0))), RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Column {
                Text("Clipperdirac", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("Lambi video se viral clips, title aur captions", fontSize = 13.sp, color = Color(0xFFE6E9F5))
            }
        }

        ProCard {
            SectionTitle("1 · Source videos")
            Button(onClick = { pick.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (vm.videos.isEmpty()) "Video chuno (ek ya kai)" else "Aur videos jodo")
            }
            vm.videos.forEachIndexed { i, v ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("🎞  ${v.name}", Modifier.weight(1f), fontSize = 13.sp, maxLines = 1)
                    TextButton(onClick = { vm.removeVideo(i) }) { Text("✕") }
                }
            }
            if (vm.videos.size > 1) Text("Queue: ek-ek karke sab videos process hongi", fontSize = 11.sp, color = Muted)
            OutlinedTextField(
                value = s.creator, onValueChange = { vm.update(s.copy(creator = it)) },
                label = { Text("Source creator / channel (jaise MrBeast)") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        }

        ProCard {
            SectionTitle("2 · Language")
            Text("Video me bolne ki language", fontSize = 12.sp, color = Muted)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Transcriber.LANGS.forEach { (code, label) ->
                    FilterChip(s.language == code, { vm.update(s.copy(language = code)) }, { Text(label) })
                }
            }
            if (s.language == "hi") {
                Text("Hindi captions kaise likhe", fontSize = 12.sp, color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(s.hindiScript == "roman", { vm.update(s.copy(hindiScript = "roman")) }, { Text("Hinglish (Roman)") })
                    FilterChip(s.hindiScript == "dev", { vm.update(s.copy(hindiScript = "dev")) }, { Text("हिंदी (Devanagari)") })
                }
            }
            Text("Title / description / caption language", fontSize = 12.sp, color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(s.outLang == "same", { vm.update(s.copy(outLang = "same")) }, { Text("Video wali") })
                FilterChip(s.outLang == "en", { vm.update(s.copy(outLang = "en")) }, { Text("English") })
            }
        }

        ProCard {
            SectionTitle("3 · Clips")
            Text("Clip length", fontSize = 12.sp, color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15 to 30, 30 to 60, 60 to 90).forEach { (a, b) ->
                    FilterChip(
                        s.minSec == a && s.maxSec == b,
                        { vm.update(s.copy(minSec = a, maxSec = b)) },
                        { Text("$a-${b}s") }
                    )
                }
            }
            Text("Kitni clips: ${s.clips}", fontSize = 12.sp, color = Muted)
            Slider(
                value = s.clips.toFloat(),
                onValueChange = { vm.update(s.copy(clips = it.toInt())) },
                valueRange = 1f..10f, steps = 8
            )
            OutlinedTextField(
                value = s.instruction, onValueChange = { vm.update(s.copy(instruction = it)) },
                label = { Text("AI ko instruction (optional)") },
                placeholder = { Text("jaise: sirf funny moments / paise wali baatein") },
                minLines = 2, modifier = Modifier.fillMaxWidth()
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { vm.start() },
                enabled = !vm.running,
                modifier = Modifier.weight(1f)
            ) { Text("🚀  Clips banao", fontSize = 16.sp, modifier = Modifier.padding(vertical = 6.dp)) }
            if (vm.running) OutlinedButton(onClick = { vm.stop() }) { Text("Stop") }
        }

        if (vm.status.isNotBlank() || vm.logLines.isNotEmpty()) {
            ProCard {
                if (vm.status.isNotBlank()) Text(vm.status, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                if (vm.running) LinearProgressIndicator(progress = { vm.progress }, modifier = Modifier.fillMaxWidth())
                vm.logLines.forEach { Text(it, fontSize = 11.sp, color = Muted) }
            }
        }
    }
}

// ---------------------------------------------------------------- library
@Composable
fun LibraryScreen(vm: AppViewModel) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Library", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Text("Clip pe tap karke preview, ✏️ Edit se trim / caption theek karo", fontSize = 12.sp, color = Muted)
        if (vm.running || vm.status.isNotBlank()) {
            ProCard {
                Text(vm.status, fontSize = 13.sp)
                if (vm.running) LinearProgressIndicator(progress = { vm.progress }, modifier = Modifier.fillMaxWidth())
            }
        }
        if (vm.projects.isEmpty()) {
            ProCard { Text("Abhi koi clip nahi. Create tab se shuru karo.", color = Muted) }
        }
        vm.projects.forEach { p ->
            Text("📁 ${p.folder}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            p.clips.forEachIndexed { i, c -> ClipCard(vm, p.folder, i, c) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ClipCard(vm: AppViewModel, folder: String, index: Int, rec: ClipRecord) {
    val ctx = LocalContext.current
    var expanded by remember { mutableStateOf(false) }
    var play by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var start by remember(rec.uri) { mutableStateOf(rec.start) }
    var end by remember(rec.uri) { mutableStateOf(rec.end) }
    var caps by remember(rec.uri) { mutableStateOf(rec.capsText) }
    var headline by remember(rec.uri) { mutableStateOf(rec.headline) }
    var views by remember(rec.uri) { mutableStateOf(if (rec.views > 0) rec.views.toString() else "") }
    val thumb by produceState<Bitmap?>(null, rec.uri) {
        value = withContext(Dispatchers.IO) {
            try { ctx.contentResolver.loadThumbnail(Uri.parse(rec.uri), Size(360, 640), null) } catch (e: Exception) { null }
        }
    }

    ProCard {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(width = 78.dp, height = 138.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F1218))
                    .clickable { play = true },
                contentAlignment = Alignment.Center
            ) {
                val b = thumb
                if (b != null) Image(bitmap = b.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Text("▶", fontSize = 26.sp, color = Color.White)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (rec.score > 0) ScoreBadge(rec.score)
                    Spacer(Modifier.width(8.dp))
                    Text("${rec.dur.toInt()}s", fontSize = 12.sp, color = Muted)
                }
                Text(rec.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                if (rec.ytTitle.isNotBlank()) Text("YT: ${rec.ytTitle}", fontSize = 12.sp, color = Muted, maxLines = 2)
                if (rec.reason.isNotBlank()) Text(rec.reason, fontSize = 11.sp, color = Muted, maxLines = 3)
            }
        }
        FlowRow {
            TextButton(onClick = { play = true }) { Text("▶ Play") }
            TextButton(onClick = { shareClip(ctx, rec.uri) }) { Text("Share") }
            if (rec.ytTitle.isNotBlank()) TextButton(onClick = {
                copyText(ctx, listOf(rec.ytTitle, rec.ytDesc, rec.hashtags).filter { it.isNotBlank() }.joinToString("\n\n"))
            }) { Text("Copy YT") }
            if (rec.igCaption.isNotBlank()) TextButton(onClick = {
                copyText(ctx, listOf(rec.igCaption, rec.hashtags).filter { it.isNotBlank() }.joinToString("\n\n"))
            }) { Text("Copy IG") }
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "Edit band" else "✏️ Edit") }
        }
        if (expanded) {
            HorizontalDivider(color = OutlineC)
            Text("Trim (source video ke seconds)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Stepper("Start", start) { start = it.coerceIn(0.0, end - 3.0) }
            Stepper("End", end) { end = it.coerceAtLeast(start + 3.0) }
            OutlinedTextField(
                value = caps, onValueChange = { caps = it },
                label = { Text("Captions (galat shabd theek karo)") },
                minLines = 3, modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = headline, onValueChange = { headline = it },
                label = { Text("Headline (Settings me ON ho to upar dikhega)") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = views, onValueChange = { views = it.filter(Char::isDigit) },
                    label = { Text("Views (AI seekhega)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedButton(onClick = { vm.setViews(folder, index, views.toLongOrNull() ?: 0L) }) { Text("Save") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !vm.running,
                    onClick = { vm.rerender(folder, index, start, end, caps, headline) },
                    modifier = Modifier.weight(1f)
                ) { Text("🔄 Re-render") }
                OutlinedButton(onClick = { confirmDelete = true }) { Text("🗑 Delete") }
            }
        }
    }

    if (play) PlayerDialog(rec.uri) { play = false }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Clip delete karni hai?") },
            text = { Text("Gallery se bhi hat jayegi.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.deleteClip(folder, index) }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun Stepper(label: String, value: Double, onChange: (Double) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, Modifier.width(48.dp), fontSize = 13.sp)
        OutlinedButton(onClick = { onChange(value - 0.5) }) { Text("−0.5") }
        Text(fmtTime(value), Modifier.width(70.dp), textAlign = TextAlign.Center, fontSize = 14.sp)
        OutlinedButton(onClick = { onChange(value + 0.5) }) { Text("+0.5") }
    }
}

@Composable
fun PlayerDialog(uri: String, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(16.dp), color = Color.Black,
            modifier = Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.88f)
        ) {
            Box {
                AndroidView(
                    factory = { c ->
                        VideoView(c).apply {
                            setVideoURI(Uri.parse(uri))
                            setMediaController(MediaController(c).also { it.setAnchorView(this) })
                            setOnPreparedListener { mp -> mp.isLooping = true; start() }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.TopEnd)) { Text("✕ Close") }
            }
        }
    }
}

// -------------------------------------------------------------- campaigns
private val STATUSES = listOf("Submitted", "Approved", "Paid", "Rejected")
private val PLATFORMS = listOf("Vyro", "Whop", "ContentRewards", "Other")

@Composable
fun RowScope.Stat(value: String, label: String) {
    Column(Modifier.weight(1f)) {
        Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
        Text(label, fontSize = 11.sp, color = Muted)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CampaignsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    var form by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Campaign?>(null) }
    val list = vm.campaigns
    val totalViews = list.sumOf { it.views }
    val est = list.filter { it.status != "Rejected" }.sumOf { it.views / 1000.0 * it.cpm }
    val paid = list.filter { it.status == "Paid" }.sumOf { it.views / 1000.0 * it.cpm }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Campaigns", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Text("Vyro / Whop / Content Rewards me submit ki hui clips ka hisaab", fontSize = 12.sp, color = Muted)
        ProCard {
            Row(Modifier.fillMaxWidth()) {
                Stat(String.format(Locale.US, "%,d", totalViews), "Total views")
                Stat(String.format(Locale.US, "$%.2f", est), "Est. kamai")
                Stat(String.format(Locale.US, "$%.2f", paid), "Paid")
            }
        }
        Button(onClick = { editing = null; form = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Submission add karo") }
        if (list.isEmpty()) ProCard { Text("Abhi koi entry nahi. Link, views aur CPM yahan likh ke kamai track karo.", color = Muted) }
        list.forEach { c ->
            ProCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${c.platform} · ${c.name}", fontWeight = FontWeight.SemiBold)
                        if (c.creator.isNotBlank()) Text(c.creator, fontSize = 12.sp, color = Muted)
                    }
                    Text(
                        String.format(Locale.US, "$%.2f", c.views / 1000.0 * c.cpm),
                        fontWeight = FontWeight.Bold, color = Accent
                    )
                }
                Text(
                    "${String.format(Locale.US, "%,d", c.views)} views · CPM $${String.format(Locale.US, "%.2f", c.cpm)}",
                    fontSize = 12.sp, color = Muted
                )
                FlowRow {
                    TextButton(onClick = {
                        val next = STATUSES[(STATUSES.indexOf(c.status) + 1) % STATUSES.size]
                        vm.saveCampaign(c.copy(status = next))
                    }) { Text("● ${c.status}") }
                    TextButton(onClick = { editing = c; form = true }) { Text("Edit") }
                    if (c.link.isNotBlank()) TextButton(onClick = { copyText(ctx, c.link) }) { Text("Copy link") }
                    TextButton(onClick = { vm.deleteCampaign(c.id) }) { Text("Delete") }
                }
            }
        }
    }
    if (form) CampaignDialog(editing, onDismiss = { form = false }) { vm.saveCampaign(it); form = false }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CampaignDialog(initial: Campaign?, onDismiss: () -> Unit, onSave: (Campaign) -> Unit) {
    var platform by remember { mutableStateOf(initial?.platform ?: PLATFORMS[0]) }
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var creator by remember { mutableStateOf(initial?.creator ?: "") }
    var link by remember { mutableStateOf(initial?.link ?: "") }
    var status by remember { mutableStateOf(initial?.status ?: STATUSES[0]) }
    var views by remember { mutableStateOf(if ((initial?.views ?: 0L) > 0) initial!!.views.toString() else "") }
    var cpm by remember { mutableStateOf(if ((initial?.cpm ?: 0.0) > 0) initial!!.cpm.toString() else "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Submission add karo" else "Submission edit") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PLATFORMS.forEach { p -> FilterChip(platform == p, { platform = p }, { Text(p, fontSize = 12.sp) }) }
                }
                OutlinedTextField(name, { name = it }, label = { Text("Campaign / clip naam") }, singleLine = true)
                OutlinedTextField(creator, { creator = it }, label = { Text("Creator") }, singleLine = true)
                OutlinedTextField(link, { link = it }, label = { Text("Post link") }, singleLine = true)
                OutlinedTextField(
                    views, { views = it.filter(Char::isDigit) }, label = { Text("Views") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(
                    cpm, { cpm = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("CPM ($ per 1000 views)") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    STATUSES.forEach { st -> FilterChip(status == st, { status = st }, { Text(st, fontSize = 12.sp) }) }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    Campaign(
                        id = initial?.id ?: System.currentTimeMillis(), platform = platform, name = name.ifBlank { "Clip" },
                        creator = creator, link = link, status = status,
                        views = views.toLongOrNull() ?: 0L, cpm = cpm.toDoubleOrNull() ?: 0.0
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ---------------------------------------------------------------- settings
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val s = vm.settings
    var advanced by remember { mutableStateOf(false) }
    val pickMusic = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { persist(ctx, uri); vm.update(s.copy(musicUri = uri.toString())) }
    }
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { persist(ctx, uri); vm.update(s.copy(logoUri = uri.toString())) }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)

        ProCard {
            SectionTitle("API Keys (jitni chahe)")
            OutlinedTextField(
                value = s.keys, onValueChange = { vm.update(s.copy(keys = it)) },
                label = { Text("Ek line me ek key paste karo") }, minLines = 3, modifier = Modifier.fillMaxWidth()
            )
            Text(KeyParser.summary(s.keys), fontSize = 12.sp)
            Text(
                "\"xai-\" se shuru = Grok, baaki sab Gemini. Keys sirf aapke phone me save hoti hain. " +
                    "Baari-baari use hoti hain; limit lage to agli key.",
                fontSize = 11.sp, color = Muted
            )
            TextButton(onClick = { advanced = !advanced }) { Text(if (advanced) "Advanced chhupao" else "Advanced (model ka naam)") }
            if (advanced) {
                OutlinedTextField(
                    value = s.geminiModel, onValueChange = { vm.update(s.copy(geminiModel = it)) },
                    label = { Text("Gemini model (khali = gemini-flash-latest)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = s.grokModel, onValueChange = { vm.update(s.copy(grokModel = it)) },
                    label = { Text("Grok model (khali = auto, newest fast)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            }
        }

        ProCard {
            SectionTitle("Captions")
            SwitchRow("Bade captions (word-by-word)", s.captions) { vm.update(s.copy(captions = it)) }
            Text("Caption style", fontSize = 12.sp, color = Muted)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CAP_STYLES.forEach { st ->
                    FilterChip(s.captionStyle == st.id, { vm.update(s.copy(captionStyle = st.id)) }, { Text(st.label) })
                }
            }
            SwitchRow("Upar bada headline text", s.headline) { vm.update(s.copy(headline = it)) }
        }

        ProCard {
            SectionTitle("Smart editing")
            SwitchRow("Smart analyst + trend research", s.analyst) { vm.update(s.copy(analyst = it)) }
            SwitchRow("Sabse gripping line pehle (cold open)", s.coldOpen) { vm.update(s.copy(coldOpen = it)) }
            SwitchRow("Pause, umm, hmm kaato", s.cutPauses) { vm.update(s.copy(cutPauses = it)) }
            SwitchRow("Auto zoom (cut pe punch-in)", s.zoom) { vm.update(s.copy(zoom = it)) }
            SwitchRow("Face follow + zaroorat par face zoom", s.faceFollow) { vm.update(s.copy(faceFollow = it)) }
            Text("Video layout", fontSize = 12.sp, color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(s.layout == "fill", { vm.update(s.copy(layout = "fill")) }, { Text("Fill (crop)") })
                FilterChip(s.layout == "fit", { vm.update(s.copy(layout = "fit")) }, { Text("Fit (poori frame)") })
            }
        }

        ProCard {
            SectionTitle("Sound")
            SwitchRow("Whoosh sound effects", s.sfx) { vm.update(s.copy(sfx = it)) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { pickMusic.launch(arrayOf("audio/*")) }) {
                    Text(if (s.musicUri.isBlank()) "Background music" else "Music badlo")
                }
                if (s.musicUri.isNotBlank()) TextButton(onClick = { vm.update(s.copy(musicUri = "")) }) { Text("Hatao") }
            }
            if (s.musicUri.isNotBlank()) {
                Text("Music volume", fontSize = 12.sp, color = Muted)
                Slider(value = s.musicVol, onValueChange = { vm.update(s.copy(musicVol = it)) }, valueRange = 0.03f..0.4f)
                SwitchRow("Bolte waqt music halka (ducking)", s.duck) { vm.update(s.copy(duck = it)) }
            }
        }

        ProCard {
            SectionTitle("Branding & quality")
            OutlinedTextField(
                value = s.handle, onValueChange = { vm.update(s.copy(handle = it)) },
                label = { Text("Apna handle (video pe neeche likha aayega)") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { pickLogo.launch(arrayOf("image/*")) }) {
                    Text(if (s.logoUri.isBlank()) "Logo watermark" else "Logo badlo")
                }
                if (s.logoUri.isNotBlank()) TextButton(onClick = { vm.update(s.copy(logoUri = "")) }) { Text("Hatao") }
            }
            Text("Export quality", fontSize = 12.sp, color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(s.quality == 1080, { vm.update(s.copy(quality = 1080)) }, { Text("1080p") })
                FilterChip(s.quality == 720, { vm.update(s.copy(quality = 720)) }, { Text("720p (tez)") })
            }
        }
        Text("Clipperdirac v1.1", fontSize = 11.sp, color = Muted, modifier = Modifier.padding(bottom = 8.dp))
    }
}
